/* Copyright 2020-2024 The MathWorks, Inc. */
#ifndef _MW_V4L2_CAPTURE_H_
#define _MW_V4L2_CAPTURE_H_

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) || defined(RSIM_WITH_SL_SOLVER))

#define EXT_webcamInit(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12) (0)
#define EXT_webcamCapture(p1,p2,p3,p4,p5,p6) (0)
#define EXT_webcamReadFrame(p1,p2,p3,p4,p5) (0)
#define EXT_webcamTerminate(p1,p2) (0)
#define EXT_updateV4L2Control(p1,p2,p3,p4) (0)

#else

#include "rtwtypes.h"

//#define _MW_V4L2_DEBUG_LVL2_  (1)
//#define _MW_V4L2_DEBUG_       (1)

enum MW_PIXEL_FORMAT {
    MW_YCBCR422 = 1,      /* Index starts at zero to match MATLAB conventions */
    MW_RGB,
    NOT_SUPPORTED, /* Not supported from down here */
};

typedef enum {
    PIXEL_ORDER_INTERLEAVED = 1, /* Index starts at zero to match MATLAB conventions */
    PIXEL_ORDER_PLANAR,
} MW_PIXEL_ORDER;

/* Code generation */
#define MW_ERROR_EXIT(msg)                    fprintf(stderr, msg); \
videoCaptureCleanup();
#define MW_ERROR_EXIT1(msg, arg1)             fprintf(stderr, msg, arg1); \
videoCaptureCleanup();
#define MW_ERROR_EXIT2(msg, arg1, arg2)       fprintf(stderr, msg, arg1, arg2); \
videoCaptureCleanup();
#define MW_ERROR_EXIT3(msg, arg1, arg2, arg3) fprintf(stderr, msg, arg1, arg2, arg3); \
videoCaptureCleanup();
#define MW_ERROR_EXIT4(msg, arg1, arg2, arg3, arg4) fprintf(stderr, msg, arg1, arg2, arg3, arg4); \
videoCaptureCleanup();
#define MW_WARNING3(msg, arg1, arg2, arg3)    fprintf(stderr, msg, arg1, arg2, arg3)

#define MW_NUM_FRAMES_DELAY      (4)
#define MW_NUM_MAX_VIDEO_DEVICES (8)
#define MW_NUM_COLOR_PLANES      (3)
#define ERR_MSG_BUF_SIZE         (512)

typedef enum {
    IO_METHOD_READ,
    IO_METHOD_MMAP,
    IO_METHOD_USERPTR,
} MW_IO_METHOD;

typedef enum {
    SIM_OUTPUT_COLORBARS = 1,    /* Index starts at zero to match MATLAB conventions */
    SIM_OUTPUT_BLACK,
    SIM_OUTPUT_WHITE,
    SIM_OUTPUT_LIVE_VIDEO,
} MW_SIM_OUTPUT;

typedef struct {
    int32_T top;
    int32_T left;
    int32_T width;
    int32_T height;
} MW_rect_t;

typedef struct {
    uint32_T width;
    uint32_T height;
    uint32_T pln12Width;
    uint32_T pixelFormat;
} MW_imFormat_t;

typedef struct {
    void *start;
    size_t length;
} MW_frmInfo_t;

/* Structure holding device information */
typedef struct {
    int fd;                         /* handle to device */
    uint8_T *devName;               /* i.e. "/dev/video0" */
    MW_rect_t roi;                  /* Stores cropping rectangle (ROI from block mask) */
    MW_imFormat_t imFormat;         /* Stores image size and pixel format */
    int pixelOrder;                 /* Interleave / planar selection */
    real_T frameRate;               /* 1/sampletime */
    int simOutput;                  /* Generated output in simulation */
    unsigned int frmCount;
    unsigned int v4l2BufCount;
    unsigned int v4l2CaptureStarted;
    MW_frmInfo_t frm[MW_NUM_FRAMES_DELAY];
    uint8_T *hRgbRefLine;           /* RGB reference line for sim devices */
    MW_IO_METHOD ioMethod;          /* I/O method used */
} MW_videoInfo_t;

#ifdef __cplusplus
extern "C"
{
#endif
int EXT_webcamInit
(       
        uint8_T isMLTGT,        /* p1 */
        uint8_T id,             /* p2 */
        int32_T roiTop,         /* p3 */
        int32_T roiLeft,        /* p4 */
        int32_T roiWidth,       /* p5 */
        int32_T roiHeight,      /* p6 */
        uint32_T imWidth,       /* p7 */
        uint32_T imHeight,      /* p8 */
        uint32_T pixelFormat,   /* p9 */
        uint32_T pixelOrder,    /* p10 */
        uint32_T simOutput,     /* p11 */
        real_T sampleTime       /* p12 */
        );

int EXT_webcamCapture(uint8_T isMLTGT,uint8_T id, double *ts, uint8_T *pln0, uint8_T *pln1, uint8_T *pln2);
int EXT_webcamReadFrame(uint8_T id, double *ts, uint8_T *pln0, uint8_T *pln1, uint8_T *pln2);
int EXT_webcamTerminate(uint8_T isMLTGT,uint8_T id);
void EXT_updateV4L2Control(char_T* controlID, real32_T value, uint8_T id, uint8_T *status);
uint32_T getBytesPerLine(uint32_T pixelFormat, uint32_T width);

#ifdef __cplusplus
}
#endif

#endif /* RSIM else ends here */
#endif /*_MW_V4L2_CAPTURE_H_*/

/* LocalWords:  dev sampletime
 */
