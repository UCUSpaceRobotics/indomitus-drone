/* Copyright 2020 - 2026 The MathWorks, Inc. */
#ifndef _MW_AVAILABLEWEBCAM_H_
#define _MW_AVAILABLEWEBCAM_H_

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) || defined(RSIM_WITH_SL_SOLVER))

#define getCameraList() (0)
#define validateResolution(camIndex, imwidth, imheight) (1)
#define getCameraAddrIndex(cameraName, cameraNameLen) (0)

#else


#define MW_REPORT_ERROR(msg)                    fprintf(stderr, msg); 
#define MW_REPORT_ERROR_ARGS1(msg, arg1) fprintf(stderr, msg, arg1); 
#define MW_REPORT_ERROR_ARGS2(msg, arg1, arg2) fprintf(stderr, msg, arg1, arg2); 
#define MW_REPORT_ERROR_ARGS3(msg, arg1, arg2, arg3) fprintf(stderr, msg, arg1, arg2, arg3); 



#ifdef __cplusplus
extern "C"
{
#endif

void getCameraList();
int validateResolution(int camIndex, int imWidth, int imHeight);
int getCameraAddrIndex(char* const cameraName, unsigned int cameraNameLen);
int getCameraDeviceNumFromIndex(unsigned int index);
#ifdef __cplusplus
}
#endif

#endif /* RSIM else ends here */
#endif /* MW_AVAILABLEWEBCAM_H */
