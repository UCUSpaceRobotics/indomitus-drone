#ifndef ERC_VISION_NODE__VISIBILITY_CONTROL_H_
#define ERC_VISION_NODE__VISIBILITY_CONTROL_H_
#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define ERC_VISION_NODE_EXPORT __attribute__ ((dllexport))
    #define ERC_VISION_NODE_IMPORT __attribute__ ((dllimport))
  #else
    #define ERC_VISION_NODE_EXPORT __declspec(dllexport)
    #define ERC_VISION_NODE_IMPORT __declspec(dllimport)
  #endif
  #ifdef ERC_VISION_NODE_BUILDING_LIBRARY
    #define ERC_VISION_NODE_PUBLIC ERC_VISION_NODE_EXPORT
  #else
    #define ERC_VISION_NODE_PUBLIC ERC_VISION_NODE_IMPORT
  #endif
  #define ERC_VISION_NODE_PUBLIC_TYPE ERC_VISION_NODE_PUBLIC
  #define ERC_VISION_NODE_LOCAL
#else
  #define ERC_VISION_NODE_EXPORT __attribute__ ((visibility("default")))
  #define ERC_VISION_NODE_IMPORT
  #if __GNUC__ >= 4
    #define ERC_VISION_NODE_PUBLIC __attribute__ ((visibility("default")))
    #define ERC_VISION_NODE_LOCAL  __attribute__ ((visibility("hidden")))
  #else
    #define ERC_VISION_NODE_PUBLIC
    #define ERC_VISION_NODE_LOCAL
  #endif
  #define ERC_VISION_NODE_PUBLIC_TYPE
#endif
#endif  // ERC_VISION_NODE__VISIBILITY_CONTROL_H_
// Generated 17-Aug-2026 17:32:27
 