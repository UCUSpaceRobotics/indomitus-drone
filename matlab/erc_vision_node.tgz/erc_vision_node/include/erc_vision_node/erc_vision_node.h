//
// Sponsored License - for use in support of a program or activity
// sponsored by MathWorks.  Not for government, commercial or other
// non-sponsored organizational use.
//
// File: erc_vision_node.h
//
// Code generated for Simulink model 'erc_vision_node'.
//
// Model version                  : 1.9
// Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
// C/C++ source code generated on : Mon Aug 17 17:32:15 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-A (64-bit)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef ERC_VISION_NODE_H_
#define ERC_VISION_NODE_H_
#include "rtwtypes.h"
#include "erc_vision_node_types.h"
#include "coder_array.h"
#include "readArucoMarkerCore_api.hpp"

extern "C"
{

#include "rt_nonfinite.h"

}

extern "C"
{

#include "rtGetInf.h"

}

extern "C"
{

#include "rtGetNaN.h"

}

#include <stddef.h>

// Block signals (default storage)
struct B_erc_vision_node_T {
  coder::array<int32_T,2> famLength;
  coder::array<char_T,2> familyNames;
  cameraIntrinsics_erc_vision_n_T intrinsics;
  c_images_geotrans_internal_ri_T b;
  c_images_geotrans_internal_ri_T dataArray_data;
  coder::array<c_images_geotrans_internal_ri_T,2> rhs_Data;
  coder::array<c_images_geotrans_internal_ri_T,2> dataArray;
  coder::array<real_T,2> ids;
  coder::array<real_T,2> transVectors;
  coder::array<real_T,3> a__1;
  coder::array<real_T,3> rejectionsCell;
  coder::array<real_T,3> locs;
  coder::array<real_T,3> rotMatrices;
  rigidtform3d_erc_vision_node_T poses;
  uint8_T frame[921600];
  uint8_T c_I[921600];
  uint8_T uv[307200];
  uint8_T varargin_1[307200];
  uint8_T varargin_2[307200];
  uint8_T varargin_3[307200];
  ArucoDetectorParams b_m;
  real_T dataArray_data_c[16];
  char_T b_errorMessage[101];
  real_T dataArray_data_k[12];
  real_T camMatrix[9];
  real_T expl_temp_data[9];
  real_T R_clamped_data[9];
  real_T b_data[9];
  real_T y_data[9];
  real_T b_A_data[9];
  real_T b_A_data_c[9];
  real_T distCoeffs[5];
  real_T j_data[4];
  real_T i_data[4];
  SL_Bus_geometry_msgs_Point BusAssignment;// '<Root>/Bus Assignment'
  real_T b_Translation[3];
  real_T expl_temp_data_b[3];
  real_T transVectors_data[3];
  real_T s_data[3];
  real_T tmp_data[3];
  real_T s_data_p[3];
  real_T e_data[3];
  real_T work_data[3];
  real_T b_s_data[3];
  real_T e_data_c[3];
  real_T work_data_f[3];
  char_T markersProc[20];
  char_T b_zeroDelimTopic[20];
  char_T i[18];
  real_T smax;
  real_T b_s;
  real_T d;
  real_T Rc;
  real_T absx;
  real_T cscale;
  real_T anrm;
  real_T nrm;
  real_T rt;
  real_T r;
  real_T ztest;
  real_T smm1;
  real_T emm1;
  real_T shift;
  real_T cfromc;
  real_T ctoc;
  real_T cfrom1;
  real_T cto1;
  real_T mul;
  real_T cscale_g;
  real_T anrm_g;
  real_T nrm_m;
  real_T rt_n;
  real_T r_p;
  real_T smm1_l;
  real_T emm1_j;
  real_T sqds;
  real_T shift_d;
  real_T roe;
  real_T absa;
  real_T absb;
  real_T scale;
  real_T cfromc_g;
  real_T ctoc_l;
  real_T cfrom1_d;
  real_T cto1_d;
  real_T mul_l;
  real_T scale_o;
  real_T absxk;
  real_T t;
  real_T scale_b;
  real_T absxk_n;
  real_T t_b;
  real_T ads;
  real_T absxk_l;
  int32_T markersLength[2];
  int32_T expl_temp_size[2];
  int32_T b_size[2];
  int32_T y_size[2];
  int32_T targetIdx;
  int32_T i_h;
  int32_T rejectionLength;
  int32_T poseLength;
  int32_T n;
  int32_T loop_ub;
  int32_T i_b;
  int32_T i1;
  int32_T i2;
  int32_T jj;
  int32_T a;
  int32_T d_k;
  int32_T yk;
  int32_T f_k;
  int32_T jA;
  int32_T e;
  int32_T ijA;
  int32_T s_size;
  int32_T ipiv_data_tmp;
  uint32_T numDetections;
};

// Block states (default storage) for system '<Root>'
struct DW_erc_vision_node_T {
  codertarget_raspi_internal_Ra_T obj; // '<Root>/V4L2 Video Capture'
  ros_slros2_internal_block_Pub_T obj_h;// '<S3>/SinkBlock'
};

// Real-time Model Data Structure
struct tag_RTM_erc_vision_node_T {
  const char_T * volatile errorStatus;
  const char_T* getErrorStatus() const;
  void setErrorStatus(const char_T* const volatile aErrorStatus);
};

// Class declaration for model erc_vision_node
class erc_vision_node
{
  // public data and function members
 public:
  // Real-Time Model get method
  RT_MODEL_erc_vision_node_T * getRTM();

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  erc_vision_node();

  // Destructor
  ~erc_vision_node();

  // private data and function members
 private:
  // Block signals
  B_erc_vision_node_T erc_vision_node_B;

  // Block states
  DW_erc_vision_node_T erc_vision_node_DW;

  // private member function(s) for subsystem '<Root>'
  void v4l2Capture_updateV4L2Settings(codertarget_raspi_internal_Ra_T *obj,
    boolean_T forceUpdate);
  void erc_vision_node_SystemCore_step(codertarget_raspi_internal_Ra_T *obj,
    uint8_T varargout_1[307200], uint8_T varargout_2[307200], uint8_T
    varargout_3[307200]);
  void cameraIntrinsics_cameraIntrinsi(cameraIntrinsics_erc_vision_n_T *b_this);
  void erc_vision_node_xrot(real_T x_data[], int32_T ix0, int32_T iy0, real_T c,
    real_T s);
  void erc_vision_node_xrotg(real_T *a, real_T *b, real_T *c, real_T *s);
  void erc_vision_node_xswap(real_T x_data[], int32_T ix0, int32_T iy0);
  void erc_vision_node_xzlascl_j(real_T cfrom, real_T cto, int32_T m, real_T
    A_data[]);
  void erc_vision_node_xaxpy(int32_T n, real_T a, int32_T ix0, real_T y_data[],
    int32_T iy0);
  real_T erc_vision_node_xdotc(int32_T n, const real_T x_data[], int32_T ix0,
    const real_T y_data[], int32_T iy0);
  void erc_vision_node_xaxpy_ms(int32_T n, real_T a, const real_T x_data[],
    int32_T ix0, real_T y_data[], int32_T iy0);
  void erc_vision_node_xaxpy_m(int32_T n, real_T a, const real_T x_data[],
    int32_T ix0, real_T y_data[], int32_T iy0);
  real_T erc_vision_node_xnrm2_o(const real_T x_data[], int32_T ix0);
  real_T erc_vision_node_xnrm2(int32_T n, const real_T x_data[], int32_T ix0);
  void erc_vision_node_xzlascl(real_T cfrom, real_T cto, real_T A_data[]);
  real_T erc_vision_node_xzlangeM(const real_T x_data[]);
  void erc_vision_node_svd(const real_T A_data[], real_T U_data[], int32_T
    U_size[2], real_T s_data[], int32_T *s_size, real_T V_data[], int32_T
    V_size[2]);
  void erc_vision_node_svd_f(const real_T A_data[], real_T U_data[], int32_T
    *U_size);
  real_T erc_vision_node_norm(const real_T x_data[]);
  void erc_constrainToRotationMatrix3D(const real_T R_data[], real_T Rc_data[],
    int32_T Rc_size[2]);
  void erc_v_rigidtform3d_rigidtform3d(const real_T varargin_1_data[], const
    real_T varargin_2_data[], real_T b_this_Translation_data[], int32_T
    b_this_Translation_size[2], real_T b_this_R_data[], int32_T b_this_R_size[2],
    coder::array<c_images_geotrans_internal_ri_T, 2U> &b_this_Data);
  void erc_vision_node_readArucoMarker(const uint8_T b_I[921600], const
    cameraIntrinsics_erc_vision_n_T *varargin_2, coder::array<real_T, 2U>
    &varargout_1, coder::array<real_T, 3U> &varargout_2, coder::array<
    c_images_geotrans_internal_ri_T, 2U> &varargout_3_Data);
  void OneDimArrayBehaviorTransform_pa(const rigidtform3d_erc_vision_node_T
    *b_this, real_T idx, real_T this1_Translation[3]);
  void Raspiv4l2Capture_Raspiv4l2Captu(codertarget_raspi_internal_Ra_T *obj);
  void erc_vision_nod_SystemCore_setup(codertarget_raspi_internal_Ra_T *obj);
  void erc_vision__Publisher_setupImpl(const ros_slros2_internal_block_Pub_T
    *obj);

  // Real-Time Model
  RT_MODEL_erc_vision_node_T erc_vision_node_M;
};

extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'erc_vision_node'
//  '<S1>'   : 'erc_vision_node/Blank Message'
//  '<S2>'   : 'erc_vision_node/MATLAB Function'
//  '<S3>'   : 'erc_vision_node/Publish'

#endif                                 // ERC_VISION_NODE_H_

//
// File trailer for generated code.
//
// [EOF]
//
