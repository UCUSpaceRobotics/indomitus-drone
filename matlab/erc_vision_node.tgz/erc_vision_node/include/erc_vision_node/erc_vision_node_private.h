//
// Sponsored License - for use in support of a program or activity
// sponsored by MathWorks.  Not for government, commercial or other
// non-sponsored organizational use.
//
// File: erc_vision_node_private.h
//
// Code generated for Simulink model 'erc_vision_node'.
//
// Model version                  : 1.9
// Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
// C/C++ source code generated on : Mon Aug 17 17:32:15 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-A (64-bit)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef ERC_VISION_NODE_PRIVATE_H_
#define ERC_VISION_NODE_PRIVATE_H_
#include "rtwtypes.h"
#include "erc_vision_node_types.h"
#endif                                 // ERC_VISION_NODE_PRIVATE_H_

//
// File trailer for generated code.
//
// [EOF]
//
