//
// Sponsored License - for use in support of a program or activity
// sponsored by MathWorks.  Not for government, commercial or other
// non-sponsored organizational use.
//
// File: erc_vision_node_types.h
//
// Code generated for Simulink model 'erc_vision_node'.
//
// Model version                  : 1.9
// Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
// C/C++ source code generated on : Mon Aug 17 17:32:15 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-A (64-bit)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef ERC_VISION_NODE_TYPES_H_
#define ERC_VISION_NODE_TYPES_H_
#include "rtwtypes.h"
#include "coder_array.h"
#include "coder_bounded_array.h"
#ifndef DEFINED_TYPEDEF_FOR_SL_BUS_GEOMETRY_MSGS_POINT_
#define DEFINED_TYPEDEF_FOR_SL_BUS_GEOMETRY_MSGS_POINT_

// MsgType=geometry_msgs/Point
struct SL_Bus_geometry_msgs_Point
{
  real_T x;
  real_T y;
  real_T z;
};

#endif

// Custom Type definition for MATLAB Function: '<Root>/MATLAB Function'
#ifndef STRUCT_C_VISION_INTERNAL_CALIBRATION_T
#define STRUCT_C_VISION_INTERNAL_CALIBRATION_T

struct c_vision_internal_calibration_T
{
  int32_T __dummy;
};

#endif                                // STRUCT_C_VISION_INTERNAL_CALIBRATION_T

#ifndef STRUCT_C_VISION_INTERNAL_CODEGEN_CAM_T
#define STRUCT_C_VISION_INTERNAL_CODEGEN_CAM_T

struct c_vision_internal_codegen_cam_T
{
  int32_T __dummy;
};

#endif                                // STRUCT_C_VISION_INTERNAL_CODEGEN_CAM_T

#ifndef STRUCT_SJ4IH70VMKCVCEGUWN0MNVF
#define STRUCT_SJ4IH70VMKCVCEGUWN0MNVF

struct sJ4ih70VmKcvCeguWN0mNVF
{
  real_T sec;
  real_T nsec;
};

#endif                                 // STRUCT_SJ4IH70VMKCVCEGUWN0MNVF

#ifndef STRUCT_ROS_SLROS2_INTERNAL_BLOCK_PUB_T
#define STRUCT_ROS_SLROS2_INTERNAL_BLOCK_PUB_T

struct ros_slros2_internal_block_Pub_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  boolean_T QOSAvoidROSNamespaceConventions;
};

#endif                                // STRUCT_ROS_SLROS2_INTERNAL_BLOCK_PUB_T

#ifndef STRUCT_CODERTARGET_RASPI_INTERNAL_RA_T
#define STRUCT_CODERTARGET_RASPI_INTERNAL_RA_T

struct codertarget_raspi_internal_Ra_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real_T Brightness;
  real_T Saturation;
  real_T Contrast;
  real_T Sharpness;
  real_T CameraZoom;
  real_T ManualFocus;
  real_T CameraPan;
  real_T CameraTilt;
  real_T BrightnessInternal;
  real_T SaturationInternal;
  real_T ContrastInternal;
  real_T SharpnessInternal;
  real_T CameraZoomInternal;
  real_T ManualFocusInternal;
  real_T CameraPanInternal;
  real_T CameraTiltInternal;
  boolean_T EnableManualFocusInternal;
};

#endif                                // STRUCT_CODERTARGET_RASPI_INTERNAL_RA_T

#ifndef STRUCT_CAMERAINTRINSICS_ERC_VISION_N_T
#define STRUCT_CAMERAINTRINSICS_ERC_VISION_N_T

struct cameraIntrinsics_erc_vision_n_T
{
  c_vision_internal_calibration_T UndistortMap;
  real_T FocalLength[2];
  real_T PrincipalPoint[2];
  real_T ImageSize[2];
  real_T RadialDistortion[2];
  real_T TangentialDistortion[2];
  real_T Skew;
  real_T K[9];
  coder::array<c_vision_internal_codegen_cam_T, 2U> cameraIntrinsicsArrayData;
};

#endif                                // STRUCT_CAMERAINTRINSICS_ERC_VISION_N_T

#ifndef STRUCT_C_IMAGES_GEOTRANS_INTERNAL_RI_T
#define STRUCT_C_IMAGES_GEOTRANS_INTERNAL_RI_T

struct c_images_geotrans_internal_ri_T
{
  coder::bounded_array<real_T, 3U, 2U> Translation;
  coder::bounded_array<real_T, 9U, 2U> R;
};

#endif                                // STRUCT_C_IMAGES_GEOTRANS_INTERNAL_RI_T

#ifndef STRUCT_RIGIDTFORM3D_ERC_VISION_NODE_T
#define STRUCT_RIGIDTFORM3D_ERC_VISION_NODE_T

struct rigidtform3d_erc_vision_node_T
{
  coder::bounded_array<real_T, 3U, 2U> Translation;
  coder::bounded_array<real_T, 9U, 2U> R;
  coder::array<c_images_geotrans_internal_ri_T, 2U> Data;
};

#endif                                 // STRUCT_RIGIDTFORM3D_ERC_VISION_NODE_T

// Forward declaration for rtModel
typedef struct tag_RTM_erc_vision_node_T RT_MODEL_erc_vision_node_T;

#endif                                 // ERC_VISION_NODE_TYPES_H_

//
// File trailer for generated code.
//
// [EOF]
//
