// Copyright 2022-2024 The MathWorks, Inc.
// Generated 17-Aug-2026 17:32:23
#include "slros2_initialize.h"
const std::string SLROSNodeName("erc_vision_node");
// erc_vision_node/Publish
SimulinkPublisher<geometry_msgs::msg::Point,SL_Bus_geometry_msgs_Point> Pub_erc_vision_node_3;
