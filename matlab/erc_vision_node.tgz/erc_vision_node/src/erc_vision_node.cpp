//
// Sponsored License - for use in support of a program or activity
// sponsored by MathWorks.  Not for government, commercial or other
// non-sponsored organizational use.
//
// File: erc_vision_node.cpp
//
// Code generated for Simulink model 'erc_vision_node'.
//
// Model version                  : 1.9
// Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
// C/C++ source code generated on : Mon Aug 17 17:32:15 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-A (64-bit)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "erc_vision_node.h"
#include "MW_v4l2_cam.h"
#include "readArucoMarkerCore_api.hpp"
#include "slros2_initialize.h"
#include "MW_availableWebcam.h"
#include <cstdio>
#include <cstdlib>
#include "erc_vision_node_types.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include <string.h>
#include <stddef.h>
#include <math.h>

extern "C"
{

#include "rt_nonfinite.h"

}

#include "rmw/qos_profiles.h"

void erc_vision_node::v4l2Capture_updateV4L2Settings
  (codertarget_raspi_internal_Ra_T *obj, boolean_T forceUpdate)
{
  char_T j[12];
  char_T b[11];
  char_T e[10];
  char_T c[9];
  uint8_T status;
  static const char_T b_0[11] = "Brightness";
  static const char_T c_0[9] = "Contrast";
  static const char_T d[11] = "Saturation";
  static const char_T e_0[10] = "Sharpness";
  static const char_T f[10] = "CameraPan";
  static const char_T g[11] = "CameraTilt";
  static const char_T h[11] = "CameraZoom";
  static const char_T i_0[18] = "EnableManualFocus";
  static const char_T j_0[12] = "ManualFocus";

  // Start for MATLABSystem: '<Root>/V4L2 Video Capture'
  if ((obj->Brightness != obj->BrightnessInternal) || forceUpdate) {
    obj->BrightnessInternal = obj->Brightness;
    for (int32_T i = 0; i < 11; i++) {
      b[i] = b_0[i];
    }

    EXT_updateV4L2Control(&b[0], static_cast<real32_T>(obj->Brightness), 10,
                          &status);
  }

  if ((obj->Contrast != obj->ContrastInternal) || forceUpdate) {
    obj->ContrastInternal = obj->Contrast;
    for (int32_T i = 0; i < 9; i++) {
      c[i] = c_0[i];
    }

    EXT_updateV4L2Control(&c[0], static_cast<real32_T>(obj->Contrast), 10,
                          &status);
  }

  if ((obj->Saturation != obj->SaturationInternal) || forceUpdate) {
    obj->SaturationInternal = obj->Saturation;
    for (int32_T i = 0; i < 11; i++) {
      b[i] = d[i];
    }

    EXT_updateV4L2Control(&b[0], static_cast<real32_T>(obj->Saturation), 10,
                          &status);
  }

  if ((obj->Sharpness != obj->SharpnessInternal) || forceUpdate) {
    obj->SharpnessInternal = obj->Sharpness;
    for (int32_T i = 0; i < 10; i++) {
      e[i] = e_0[i];
    }

    EXT_updateV4L2Control(&e[0], static_cast<real32_T>(obj->Sharpness), 10,
                          &status);
  }

  if ((obj->CameraPan != obj->CameraPanInternal) || forceUpdate) {
    obj->CameraPanInternal = obj->CameraPan;
    for (int32_T i = 0; i < 10; i++) {
      e[i] = f[i];
    }

    EXT_updateV4L2Control(&e[0], static_cast<real32_T>(obj->CameraPan), 10,
                          &status);
  }

  if ((obj->CameraTilt != obj->CameraTiltInternal) || forceUpdate) {
    obj->CameraTiltInternal = obj->CameraTilt;
    for (int32_T i = 0; i < 11; i++) {
      b[i] = g[i];
    }

    EXT_updateV4L2Control(&b[0], static_cast<real32_T>(obj->CameraTilt), 10,
                          &status);
  }

  if ((obj->CameraZoom != obj->CameraZoomInternal) || forceUpdate) {
    obj->CameraZoomInternal = obj->CameraZoom;
    for (int32_T i = 0; i < 11; i++) {
      b[i] = h[i];
    }

    EXT_updateV4L2Control(&b[0], static_cast<real32_T>(obj->CameraZoom), 10,
                          &status);
  }

  if (obj->EnableManualFocusInternal || forceUpdate) {
    obj->EnableManualFocusInternal = false;
    for (int32_T i = 0; i < 18; i++) {
      erc_vision_node_B.i[i] = i_0[i];
    }

    EXT_updateV4L2Control(&erc_vision_node_B.i[0], 0.0F, 10, &status);
  }

  if ((obj->ManualFocus != obj->ManualFocusInternal) || forceUpdate) {
    obj->ManualFocusInternal = obj->ManualFocus;
    for (int32_T i = 0; i < 12; i++) {
      j[i] = j_0[i];
    }

    EXT_updateV4L2Control(&j[0], static_cast<real32_T>(obj->ManualFocus), 10,
                          &status);
  }

  // End of Start for MATLABSystem: '<Root>/V4L2 Video Capture'
}

void erc_vision_node::erc_vision_node_SystemCore_step
  (codertarget_raspi_internal_Ra_T *obj, uint8_T varargout_1[307200], uint8_T
   varargout_2[307200], uint8_T varargout_3[307200])
{
  real_T ts;

  // Start for MATLABSystem: '<Root>/V4L2 Video Capture'
  v4l2Capture_updateV4L2Settings(obj, false);
  EXT_webcamReadFrame(10, &ts, &varargout_1[0], &varargout_2[0], &varargout_3[0]);
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::cameraIntrinsics_cameraIntrinsi
  (cameraIntrinsics_erc_vision_n_T *b_this)
{
  c_vision_internal_codegen_cam_T b;
  b_this->FocalLength[0] = 530.0;
  b_this->PrincipalPoint[0] = 320.0;
  b_this->ImageSize[0] = 480.0;
  b_this->RadialDistortion[0] = 0.0;
  b_this->TangentialDistortion[0] = 0.0;
  b_this->FocalLength[1] = 530.0;
  b_this->PrincipalPoint[1] = 240.0;
  b_this->ImageSize[1] = 640.0;
  b_this->RadialDistortion[1] = 0.0;
  b_this->TangentialDistortion[1] = 0.0;
  b_this->Skew = 0.0;
  b_this->K[0] = b_this->FocalLength[0];
  b_this->K[3] = b_this->Skew;
  b_this->K[6] = b_this->PrincipalPoint[0];
  b_this->K[1] = 0.0;
  b_this->K[4] = b_this->FocalLength[1];
  b_this->K[7] = b_this->PrincipalPoint[1];
  b_this->K[2] = 0.0;
  b_this->K[5] = 0.0;
  b_this->K[8] = 1.0;
  b.__dummy = 0;
  b_this->cameraIntrinsicsArrayData.set_size(1, 1);
  b_this->cameraIntrinsicsArrayData[0] = b;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xrot(real_T x_data[], int32_T ix0, int32_T
  iy0, real_T c, real_T s)
{
  real_T temp;
  real_T temp_tmp;
  temp = x_data[iy0 - 1];
  temp_tmp = x_data[ix0 - 1];
  x_data[iy0 - 1] = temp * c - temp_tmp * s;
  x_data[ix0 - 1] = temp_tmp * c + temp * s;
  temp = x_data[ix0] * c + x_data[iy0] * s;
  x_data[iy0] = x_data[iy0] * c - x_data[ix0] * s;
  x_data[ix0] = temp;
  temp = x_data[iy0 + 1];
  temp_tmp = x_data[ix0 + 1];
  x_data[iy0 + 1] = temp * c - temp_tmp * s;
  x_data[ix0 + 1] = temp_tmp * c + temp * s;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xrotg(real_T *a, real_T *b, real_T *c,
  real_T *s)
{
  erc_vision_node_B.roe = *b;
  erc_vision_node_B.absa = fabs(*a);
  erc_vision_node_B.absb = fabs(*b);
  if (erc_vision_node_B.absa > erc_vision_node_B.absb) {
    erc_vision_node_B.roe = *a;
  }

  erc_vision_node_B.scale = erc_vision_node_B.absa + erc_vision_node_B.absb;
  if (erc_vision_node_B.scale == 0.0) {
    *s = 0.0;
    *c = 1.0;
    *a = 0.0;
    *b = 0.0;
  } else {
    real_T bds;
    erc_vision_node_B.ads = erc_vision_node_B.absa / erc_vision_node_B.scale;
    bds = erc_vision_node_B.absb / erc_vision_node_B.scale;
    erc_vision_node_B.scale *= sqrt(erc_vision_node_B.ads *
      erc_vision_node_B.ads + bds * bds);
    if (erc_vision_node_B.roe < 0.0) {
      erc_vision_node_B.scale = -erc_vision_node_B.scale;
    }

    *c = *a / erc_vision_node_B.scale;
    *s = *b / erc_vision_node_B.scale;
    if (erc_vision_node_B.absa > erc_vision_node_B.absb) {
      *b = *s;
    } else if (*c != 0.0) {
      *b = 1.0 / *c;
    } else {
      *b = 1.0;
    }

    *a = erc_vision_node_B.scale;
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xswap(real_T x_data[], int32_T ix0,
  int32_T iy0)
{
  real_T temp;
  temp = x_data[ix0 - 1];
  x_data[ix0 - 1] = x_data[iy0 - 1];
  x_data[iy0 - 1] = temp;
  temp = x_data[ix0];
  x_data[ix0] = x_data[iy0];
  x_data[iy0] = temp;
  temp = x_data[ix0 + 1];
  x_data[ix0 + 1] = x_data[iy0 + 1];
  x_data[iy0 + 1] = temp;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xzlascl_j(real_T cfrom, real_T cto,
  int32_T m, real_T A_data[])
{
  boolean_T notdone;
  erc_vision_node_B.cfromc = cfrom;
  erc_vision_node_B.ctoc = cto;
  notdone = true;
  while (notdone) {
    int32_T b;
    erc_vision_node_B.cfrom1 = erc_vision_node_B.cfromc * 2.004168360008973E-292;
    erc_vision_node_B.cto1 = erc_vision_node_B.ctoc / 4.9896007738368E+291;
    if ((fabs(erc_vision_node_B.cfrom1) > fabs(erc_vision_node_B.ctoc)) &&
        (erc_vision_node_B.ctoc != 0.0)) {
      erc_vision_node_B.mul = 2.004168360008973E-292;
      erc_vision_node_B.cfromc = erc_vision_node_B.cfrom1;
    } else if (fabs(erc_vision_node_B.cto1) > fabs(erc_vision_node_B.cfromc)) {
      erc_vision_node_B.mul = 4.9896007738368E+291;
      erc_vision_node_B.ctoc = erc_vision_node_B.cto1;
    } else {
      erc_vision_node_B.mul = erc_vision_node_B.ctoc / erc_vision_node_B.cfromc;
      notdone = false;
    }

    b = static_cast<uint8_T>(m);
    for (int32_T i = 0; i < b; i++) {
      A_data[i] *= erc_vision_node_B.mul;
    }
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xaxpy(int32_T n, real_T a, int32_T ix0,
  real_T y_data[], int32_T iy0)
{
  if (!(a == 0.0)) {
    for (int32_T k = 0; k < n; k++) {
      int32_T tmp;
      tmp = (iy0 + k) - 1;
      y_data[tmp] += y_data[(ix0 + k) - 1] * a;
    }
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
real_T erc_vision_node::erc_vision_node_xdotc(int32_T n, const real_T x_data[],
  int32_T ix0, const real_T y_data[], int32_T iy0)
{
  real_T d;
  int32_T b;
  d = 0.0;
  b = static_cast<uint8_T>(n);
  for (int32_T k = 0; k < b; k++) {
    d += x_data[(ix0 + k) - 1] * y_data[(iy0 + k) - 1];
  }

  return d;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xaxpy_ms(int32_T n, real_T a, const real_T
  x_data[], int32_T ix0, real_T y_data[], int32_T iy0)
{
  if (!(a == 0.0)) {
    for (int32_T k = 0; k < n; k++) {
      int32_T tmp;
      tmp = (iy0 + k) - 1;
      y_data[tmp] += x_data[(ix0 + k) - 1] * a;
    }
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xaxpy_m(int32_T n, real_T a, const real_T
  x_data[], int32_T ix0, real_T y_data[], int32_T iy0)
{
  if (!(a == 0.0)) {
    for (int32_T k = 0; k < n; k++) {
      int32_T tmp;
      tmp = (iy0 + k) - 1;
      y_data[tmp] += x_data[(ix0 + k) - 1] * a;
    }
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
real_T erc_vision_node::erc_vision_node_xnrm2_o(const real_T x_data[], int32_T
  ix0)
{
  real_T y;
  int32_T k;
  y = 0.0;
  erc_vision_node_B.scale_b = 3.312168642111238E-170;
  for (k = ix0; k <= ix0 + 1; k++) {
    erc_vision_node_B.absxk_n = fabs(x_data[k - 1]);
    if (erc_vision_node_B.absxk_n > erc_vision_node_B.scale_b) {
      erc_vision_node_B.t_b = erc_vision_node_B.scale_b /
        erc_vision_node_B.absxk_n;
      y = y * erc_vision_node_B.t_b * erc_vision_node_B.t_b + 1.0;
      erc_vision_node_B.scale_b = erc_vision_node_B.absxk_n;
    } else {
      erc_vision_node_B.t_b = erc_vision_node_B.absxk_n /
        erc_vision_node_B.scale_b;
      y += erc_vision_node_B.t_b * erc_vision_node_B.t_b;
    }
  }

  y = erc_vision_node_B.scale_b * sqrt(y);
  if (rtIsNaN(y)) {
    k = ix0;
    int32_T exitg1;
    do {
      exitg1 = 0;
      if (k <= ix0 + 1) {
        if (rtIsNaN(x_data[k - 1])) {
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        y = (rtInf);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }

  return y;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
real_T erc_vision_node::erc_vision_node_xnrm2(int32_T n, const real_T x_data[],
  int32_T ix0)
{
  real_T y;
  int32_T k;
  int32_T kend;
  y = 0.0;
  erc_vision_node_B.scale_o = 3.312168642111238E-170;
  kend = ix0 + n;
  for (k = ix0; k < kend; k++) {
    erc_vision_node_B.absxk = fabs(x_data[k - 1]);
    if (erc_vision_node_B.absxk > erc_vision_node_B.scale_o) {
      erc_vision_node_B.t = erc_vision_node_B.scale_o / erc_vision_node_B.absxk;
      y = y * erc_vision_node_B.t * erc_vision_node_B.t + 1.0;
      erc_vision_node_B.scale_o = erc_vision_node_B.absxk;
    } else {
      erc_vision_node_B.t = erc_vision_node_B.absxk / erc_vision_node_B.scale_o;
      y += erc_vision_node_B.t * erc_vision_node_B.t;
    }
  }

  y = erc_vision_node_B.scale_o * sqrt(y);
  if (rtIsNaN(y)) {
    k = ix0;
    int32_T exitg1;
    do {
      exitg1 = 0;
      if (k <= kend - 1) {
        if (rtIsNaN(x_data[k - 1])) {
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        y = (rtInf);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }

  return y;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_xzlascl(real_T cfrom, real_T cto, real_T
  A_data[])
{
  boolean_T notdone;
  erc_vision_node_B.cfromc_g = cfrom;
  erc_vision_node_B.ctoc_l = cto;
  notdone = true;
  while (notdone) {
    erc_vision_node_B.cfrom1_d = erc_vision_node_B.cfromc_g *
      2.004168360008973E-292;
    erc_vision_node_B.cto1_d = erc_vision_node_B.ctoc_l / 4.9896007738368E+291;
    if ((fabs(erc_vision_node_B.cfrom1_d) > fabs(erc_vision_node_B.ctoc_l)) &&
        (erc_vision_node_B.ctoc_l != 0.0)) {
      erc_vision_node_B.mul_l = 2.004168360008973E-292;
      erc_vision_node_B.cfromc_g = erc_vision_node_B.cfrom1_d;
    } else if (fabs(erc_vision_node_B.cto1_d) > fabs(erc_vision_node_B.cfromc_g))
    {
      erc_vision_node_B.mul_l = 4.9896007738368E+291;
      erc_vision_node_B.ctoc_l = erc_vision_node_B.cto1_d;
    } else {
      erc_vision_node_B.mul_l = erc_vision_node_B.ctoc_l /
        erc_vision_node_B.cfromc_g;
      notdone = false;
    }

    for (int32_T i = 0; i < 9; i++) {
      A_data[i] *= erc_vision_node_B.mul_l;
    }
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
real_T erc_vision_node::erc_vision_node_xzlangeM(const real_T x_data[])
{
  real_T y;
  int32_T k;
  boolean_T exitg1;
  y = 0.0;
  k = 0;
  exitg1 = false;
  while (!exitg1 && (k < 9)) {
    erc_vision_node_B.absxk_l = fabs(x_data[k]);
    if (rtIsNaN(erc_vision_node_B.absxk_l)) {
      y = (rtNaN);
      exitg1 = true;
    } else {
      if (erc_vision_node_B.absxk_l > y) {
        y = erc_vision_node_B.absxk_l;
      }

      k++;
    }
  }

  return y;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_svd(const real_T A_data[], real_T U_data[],
  int32_T U_size[2], real_T s_data[], int32_T *s_size, real_T V_data[], int32_T
  V_size[2])
{
  int32_T kase;
  int32_T m;
  int32_T qjj;
  int32_T qp1;
  int32_T qq;
  int32_T qq_tmp;
  boolean_T apply_transform;
  boolean_T doscale;
  boolean_T exitg1;
  erc_vision_node_B.b_s_data[0] = 0.0;
  erc_vision_node_B.e_data_c[0] = 0.0;
  erc_vision_node_B.work_data_f[0] = 0.0;
  erc_vision_node_B.b_s_data[1] = 0.0;
  erc_vision_node_B.e_data_c[1] = 0.0;
  erc_vision_node_B.work_data_f[1] = 0.0;
  erc_vision_node_B.b_s_data[2] = 0.0;
  erc_vision_node_B.e_data_c[2] = 0.0;
  erc_vision_node_B.work_data_f[2] = 0.0;
  U_size[0] = 3;
  U_size[1] = 3;
  V_size[0] = 3;
  V_size[1] = 3;
  for (qjj = 0; qjj < 9; qjj++) {
    erc_vision_node_B.b_A_data_c[qjj] = A_data[qjj];
    U_data[qjj] = 0.0;
    V_data[qjj] = 0.0;
  }

  doscale = false;
  erc_vision_node_B.anrm_g = erc_vision_node_xzlangeM(A_data);
  erc_vision_node_B.cscale_g = erc_vision_node_B.anrm_g;
  if ((erc_vision_node_B.anrm_g > 0.0) && (erc_vision_node_B.anrm_g <
       6.717876107567089E-139)) {
    doscale = true;
    erc_vision_node_B.cscale_g = 6.717876107567089E-139;
    erc_vision_node_xzlascl(erc_vision_node_B.anrm_g, 6.717876107567089E-139,
      erc_vision_node_B.b_A_data_c);
  }

  for (m = 0; m < 2; m++) {
    qp1 = m + 2;
    qq_tmp = 3 * m + m;
    qq = qq_tmp + 1;
    apply_transform = false;
    erc_vision_node_B.nrm_m = erc_vision_node_xnrm2(3 - m,
      erc_vision_node_B.b_A_data_c, qq_tmp + 1);
    if (erc_vision_node_B.nrm_m > 0.0) {
      apply_transform = true;
      if (erc_vision_node_B.b_A_data_c[qq_tmp] < 0.0) {
        erc_vision_node_B.nrm_m = -erc_vision_node_B.nrm_m;
      }

      erc_vision_node_B.b_s_data[m] = erc_vision_node_B.nrm_m;
      if (fabs(erc_vision_node_B.nrm_m) >= 1.0020841800044864E-292) {
        erc_vision_node_B.nrm_m = 1.0 / erc_vision_node_B.nrm_m;
        qjj = (qq_tmp - m) + 3;
        for (kase = qq; kase <= qjj; kase++) {
          erc_vision_node_B.b_A_data_c[kase - 1] *= erc_vision_node_B.nrm_m;
        }
      } else {
        qjj = (qq_tmp - m) + 3;
        for (kase = qq; kase <= qjj; kase++) {
          erc_vision_node_B.b_A_data_c[kase - 1] /= erc_vision_node_B.b_s_data[m];
        }
      }

      erc_vision_node_B.b_A_data_c[qq_tmp]++;
      erc_vision_node_B.b_s_data[m] = -erc_vision_node_B.b_s_data[m];
    } else {
      erc_vision_node_B.b_s_data[m] = 0.0;
    }

    for (kase = qp1; kase < 4; kase++) {
      qjj = (kase - 1) * 3 + m;
      if (apply_transform) {
        erc_vision_node_xaxpy(3 - m, -(erc_vision_node_xdotc(3 - m,
          erc_vision_node_B.b_A_data_c, qq_tmp + 1, erc_vision_node_B.b_A_data_c,
          qjj + 1) / erc_vision_node_B.b_A_data_c[qq_tmp]), qq_tmp + 1,
                              erc_vision_node_B.b_A_data_c, qjj + 1);
      }

      erc_vision_node_B.e_data_c[kase - 1] = erc_vision_node_B.b_A_data_c[qjj];
    }

    for (qq = m + 1; qq < 4; qq++) {
      kase = (3 * m + qq) - 1;
      U_data[kase] = erc_vision_node_B.b_A_data_c[kase];
    }

    if (m <= 0) {
      erc_vision_node_B.nrm_m = erc_vision_node_xnrm2_o
        (erc_vision_node_B.e_data_c, 2);
      if (erc_vision_node_B.nrm_m == 0.0) {
        erc_vision_node_B.e_data_c[0] = 0.0;
      } else {
        if (erc_vision_node_B.e_data_c[1] < 0.0) {
          erc_vision_node_B.e_data_c[0] = -erc_vision_node_B.nrm_m;
        } else {
          erc_vision_node_B.e_data_c[0] = erc_vision_node_B.nrm_m;
        }

        erc_vision_node_B.nrm_m = erc_vision_node_B.e_data_c[0];
        if (fabs(erc_vision_node_B.e_data_c[0]) >= 1.0020841800044864E-292) {
          erc_vision_node_B.nrm_m = 1.0 / erc_vision_node_B.e_data_c[0];
          for (qq = qp1; qq < 4; qq++) {
            erc_vision_node_B.e_data_c[qq - 1] *= erc_vision_node_B.nrm_m;
          }
        } else {
          for (qq = qp1; qq < 4; qq++) {
            erc_vision_node_B.e_data_c[qq - 1] /= erc_vision_node_B.nrm_m;
          }
        }

        erc_vision_node_B.e_data_c[1]++;
        erc_vision_node_B.e_data_c[0] = -erc_vision_node_B.e_data_c[0];
        for (qq = qp1; qq < 4; qq++) {
          erc_vision_node_B.work_data_f[qq - 1] = 0.0;
        }

        for (qq = qp1; qq < 4; qq++) {
          erc_vision_node_xaxpy_m(2, erc_vision_node_B.e_data_c[qq - 1],
            erc_vision_node_B.b_A_data_c, 3 * (qq - 1) + 2,
            erc_vision_node_B.work_data_f, 2);
        }

        for (qq = qp1; qq < 4; qq++) {
          erc_vision_node_xaxpy_ms(2, -erc_vision_node_B.e_data_c[qq - 1] /
            erc_vision_node_B.e_data_c[1], erc_vision_node_B.work_data_f, 2,
            erc_vision_node_B.b_A_data_c, 3 * (qq - 1) + 2);
        }
      }

      for (qq = qp1; qq < 4; qq++) {
        V_data[qq - 1] = erc_vision_node_B.e_data_c[qq - 1];
      }
    }
  }

  m = 1;
  erc_vision_node_B.b_s_data[2] = erc_vision_node_B.b_A_data_c[8];
  erc_vision_node_B.e_data_c[1] = erc_vision_node_B.b_A_data_c[7];
  erc_vision_node_B.e_data_c[2] = 0.0;
  U_data[6] = 0.0;
  U_data[7] = 0.0;
  U_data[8] = 1.0;
  for (qp1 = 1; qp1 >= 0; qp1--) {
    qq = 3 * qp1 + qp1;
    if (erc_vision_node_B.b_s_data[qp1] != 0.0) {
      for (kase = qp1 + 2; kase < 4; kase++) {
        qjj = ((kase - 1) * 3 + qp1) + 1;
        erc_vision_node_xaxpy(3 - qp1, -(erc_vision_node_xdotc(3 - qp1, U_data,
          qq + 1, U_data, qjj) / U_data[qq]), qq + 1, U_data, qjj);
      }

      for (qjj = qp1 + 1; qjj < 4; qjj++) {
        kase = (3 * qp1 + qjj) - 1;
        U_data[kase] = -U_data[kase];
      }

      U_data[qq]++;
      if (qp1 - 1 >= 0) {
        U_data[3 * qp1] = 0.0;
      }
    } else {
      U_data[3 * qp1] = 0.0;
      U_data[3 * qp1 + 1] = 0.0;
      U_data[3 * qp1 + 2] = 0.0;
      U_data[qq] = 1.0;
    }
  }

  for (qp1 = 2; qp1 >= 0; qp1--) {
    if ((qp1 <= 0) && (erc_vision_node_B.e_data_c[0] != 0.0)) {
      erc_vision_node_xaxpy(2, -(erc_vision_node_xdotc(2, V_data, 2, V_data, 5) /
        V_data[1]), 2, V_data, 5);
      erc_vision_node_xaxpy(2, -(erc_vision_node_xdotc(2, V_data, 2, V_data, 8) /
        V_data[1]), 2, V_data, 8);
    }

    V_data[3 * qp1] = 0.0;
    V_data[3 * qp1 + 1] = 0.0;
    V_data[3 * qp1 + 2] = 0.0;
    V_data[qp1 + 3 * qp1] = 1.0;
  }

  qp1 = 0;
  erc_vision_node_B.nrm_m = 0.0;
  for (qq = 0; qq < 3; qq++) {
    erc_vision_node_B.r_p = erc_vision_node_B.b_s_data[qq];
    if (erc_vision_node_B.r_p != 0.0) {
      erc_vision_node_B.rt_n = fabs(erc_vision_node_B.r_p);
      erc_vision_node_B.r_p /= erc_vision_node_B.rt_n;
      erc_vision_node_B.b_s_data[qq] = erc_vision_node_B.rt_n;
      if (qq + 1 < 3) {
        erc_vision_node_B.e_data_c[qq] /= erc_vision_node_B.r_p;
      }

      qjj = 3 * qq + 1;
      for (kase = qjj; kase <= qjj + 2; kase++) {
        U_data[kase - 1] *= erc_vision_node_B.r_p;
      }
    }

    if (qq + 1 < 3) {
      erc_vision_node_B.r_p = erc_vision_node_B.e_data_c[qq];
      if (erc_vision_node_B.r_p != 0.0) {
        erc_vision_node_B.rt_n = fabs(erc_vision_node_B.r_p);
        erc_vision_node_B.r_p = erc_vision_node_B.rt_n / erc_vision_node_B.r_p;
        erc_vision_node_B.e_data_c[qq] = erc_vision_node_B.rt_n;
        erc_vision_node_B.b_s_data[qq + 1] *= erc_vision_node_B.r_p;
        qjj = (qq + 1) * 3 + 1;
        for (kase = qjj; kase <= qjj + 2; kase++) {
          V_data[kase - 1] *= erc_vision_node_B.r_p;
        }
      }
    }

    erc_vision_node_B.r_p = fabs(erc_vision_node_B.b_s_data[qq]);
    erc_vision_node_B.rt_n = fabs(erc_vision_node_B.e_data_c[qq]);
    if ((erc_vision_node_B.r_p >= erc_vision_node_B.rt_n) || rtIsNaN
        (erc_vision_node_B.rt_n)) {
      erc_vision_node_B.rt_n = erc_vision_node_B.r_p;
    }

    if (!(erc_vision_node_B.nrm_m >= erc_vision_node_B.rt_n) && !rtIsNaN
        (erc_vision_node_B.rt_n)) {
      erc_vision_node_B.nrm_m = erc_vision_node_B.rt_n;
    }
  }

  while ((m + 2 > 0) && (qp1 < 75)) {
    qq = m + 1;
    exitg1 = false;
    while (!(exitg1 || (qq == 0))) {
      erc_vision_node_B.rt_n = fabs(erc_vision_node_B.e_data_c[qq - 1]);
      if (erc_vision_node_B.rt_n <= (fabs(erc_vision_node_B.b_s_data[qq - 1]) +
           fabs(erc_vision_node_B.b_s_data[qq])) * 2.220446049250313E-16) {
        erc_vision_node_B.e_data_c[qq - 1] = 0.0;
        exitg1 = true;
      } else if ((erc_vision_node_B.rt_n <= 1.0020841800044864E-292) || ((qp1 >
                   20) && (erc_vision_node_B.rt_n <= 2.220446049250313E-16 *
                           erc_vision_node_B.nrm_m))) {
        erc_vision_node_B.e_data_c[qq - 1] = 0.0;
        exitg1 = true;
      } else {
        qq--;
      }
    }

    if (m + 1 == qq) {
      kase = 4;
    } else {
      qjj = m + 2;
      kase = m + 2;
      exitg1 = false;
      while (!exitg1 && (kase >= qq)) {
        qjj = kase;
        if (kase == qq) {
          exitg1 = true;
        } else {
          erc_vision_node_B.rt_n = 0.0;
          if (kase < m + 2) {
            erc_vision_node_B.rt_n = fabs(erc_vision_node_B.e_data_c[kase - 1]);
          }

          if (kase > qq + 1) {
            erc_vision_node_B.rt_n += fabs(erc_vision_node_B.e_data_c[kase - 2]);
          }

          erc_vision_node_B.r_p = fabs(erc_vision_node_B.b_s_data[kase - 1]);
          if ((erc_vision_node_B.r_p <= 2.220446049250313E-16 *
               erc_vision_node_B.rt_n) || (erc_vision_node_B.r_p <=
               1.0020841800044864E-292)) {
            erc_vision_node_B.b_s_data[kase - 1] = 0.0;
            exitg1 = true;
          } else {
            kase--;
          }
        }
      }

      if (qjj == qq) {
        kase = 3;
      } else if (m + 2 == qjj) {
        kase = 1;
      } else {
        kase = 2;
        qq = qjj;
      }
    }

    switch (kase) {
     case 1:
      erc_vision_node_B.rt_n = erc_vision_node_B.e_data_c[m];
      erc_vision_node_B.e_data_c[m] = 0.0;
      for (qjj = m + 1; qjj >= qq + 1; qjj--) {
        erc_vision_node_xrotg(&erc_vision_node_B.b_s_data[qjj - 1],
                              &erc_vision_node_B.rt_n, &erc_vision_node_B.r_p,
                              &erc_vision_node_B.sqds);
        if (qjj > qq + 1) {
          erc_vision_node_B.rt_n = -erc_vision_node_B.sqds *
            erc_vision_node_B.e_data_c[0];
          erc_vision_node_B.e_data_c[0] *= erc_vision_node_B.r_p;
        }

        erc_vision_node_xrot(V_data, 3 * (qjj - 1) + 1, 3 * (m + 1) + 1,
                             erc_vision_node_B.r_p, erc_vision_node_B.sqds);
      }
      break;

     case 2:
      erc_vision_node_B.rt_n = erc_vision_node_B.e_data_c[qq - 1];
      erc_vision_node_B.e_data_c[qq - 1] = 0.0;
      for (qjj = qq + 1; qjj <= m + 2; qjj++) {
        erc_vision_node_xrotg(&erc_vision_node_B.b_s_data[qjj - 1],
                              &erc_vision_node_B.rt_n, &erc_vision_node_B.sqds,
                              &erc_vision_node_B.smm1_l);
        erc_vision_node_B.r_p = erc_vision_node_B.e_data_c[qjj - 1];
        erc_vision_node_B.rt_n = -erc_vision_node_B.smm1_l *
          erc_vision_node_B.r_p;
        erc_vision_node_B.e_data_c[qjj - 1] = erc_vision_node_B.r_p *
          erc_vision_node_B.sqds;
        erc_vision_node_xrot(U_data, 3 * (qjj - 1) + 1, 3 * (qq - 1) + 1,
                             erc_vision_node_B.sqds, erc_vision_node_B.smm1_l);
      }
      break;

     case 3:
      erc_vision_node_B.sqds = erc_vision_node_B.b_s_data[m + 1];
      erc_vision_node_B.r_p = fabs(erc_vision_node_B.sqds);
      erc_vision_node_B.rt_n = fabs(erc_vision_node_B.b_s_data[m]);
      if ((erc_vision_node_B.r_p >= erc_vision_node_B.rt_n) || rtIsNaN
          (erc_vision_node_B.rt_n)) {
        erc_vision_node_B.rt_n = erc_vision_node_B.r_p;
      }

      erc_vision_node_B.r_p = fabs(erc_vision_node_B.e_data_c[m]);
      if ((erc_vision_node_B.rt_n >= erc_vision_node_B.r_p) || rtIsNaN
          (erc_vision_node_B.r_p)) {
        erc_vision_node_B.r_p = erc_vision_node_B.rt_n;
      }

      erc_vision_node_B.rt_n = fabs(erc_vision_node_B.b_s_data[qq]);
      if ((erc_vision_node_B.r_p >= erc_vision_node_B.rt_n) || rtIsNaN
          (erc_vision_node_B.rt_n)) {
        erc_vision_node_B.rt_n = erc_vision_node_B.r_p;
      }

      erc_vision_node_B.r_p = fabs(erc_vision_node_B.e_data_c[qq]);
      if ((erc_vision_node_B.rt_n >= erc_vision_node_B.r_p) || rtIsNaN
          (erc_vision_node_B.r_p)) {
        erc_vision_node_B.r_p = erc_vision_node_B.rt_n;
      }

      erc_vision_node_B.rt_n = erc_vision_node_B.sqds / erc_vision_node_B.r_p;
      erc_vision_node_B.smm1_l = erc_vision_node_B.b_s_data[m] /
        erc_vision_node_B.r_p;
      erc_vision_node_B.emm1_j = erc_vision_node_B.e_data_c[m] /
        erc_vision_node_B.r_p;
      erc_vision_node_B.sqds = erc_vision_node_B.b_s_data[qq] /
        erc_vision_node_B.r_p;
      erc_vision_node_B.smm1_l = ((erc_vision_node_B.smm1_l +
        erc_vision_node_B.rt_n) * (erc_vision_node_B.smm1_l -
        erc_vision_node_B.rt_n) + erc_vision_node_B.emm1_j *
        erc_vision_node_B.emm1_j) / 2.0;
      erc_vision_node_B.emm1_j *= erc_vision_node_B.rt_n;
      erc_vision_node_B.emm1_j *= erc_vision_node_B.emm1_j;
      if ((erc_vision_node_B.smm1_l != 0.0) || (erc_vision_node_B.emm1_j != 0.0))
      {
        erc_vision_node_B.shift_d = sqrt(erc_vision_node_B.smm1_l *
          erc_vision_node_B.smm1_l + erc_vision_node_B.emm1_j);
        if (erc_vision_node_B.smm1_l < 0.0) {
          erc_vision_node_B.shift_d = -erc_vision_node_B.shift_d;
        }

        erc_vision_node_B.shift_d = erc_vision_node_B.emm1_j /
          (erc_vision_node_B.smm1_l + erc_vision_node_B.shift_d);
      } else {
        erc_vision_node_B.shift_d = 0.0;
      }

      erc_vision_node_B.rt_n = (erc_vision_node_B.sqds + erc_vision_node_B.rt_n)
        * (erc_vision_node_B.sqds - erc_vision_node_B.rt_n) +
        erc_vision_node_B.shift_d;
      erc_vision_node_B.r_p = erc_vision_node_B.e_data_c[qq] /
        erc_vision_node_B.r_p * erc_vision_node_B.sqds;
      for (qq_tmp = qq + 1; qq_tmp <= m + 1; qq_tmp++) {
        erc_vision_node_xrotg(&erc_vision_node_B.rt_n, &erc_vision_node_B.r_p,
                              &erc_vision_node_B.sqds, &erc_vision_node_B.smm1_l);
        if (qq_tmp > qq + 1) {
          erc_vision_node_B.e_data_c[0] = erc_vision_node_B.rt_n;
        }

        erc_vision_node_B.r_p = erc_vision_node_B.e_data_c[qq_tmp - 1];
        erc_vision_node_B.emm1_j = erc_vision_node_B.b_s_data[qq_tmp - 1];
        erc_vision_node_B.e_data_c[qq_tmp - 1] = erc_vision_node_B.r_p *
          erc_vision_node_B.sqds - erc_vision_node_B.emm1_j *
          erc_vision_node_B.smm1_l;
        erc_vision_node_B.rt_n = erc_vision_node_B.smm1_l *
          erc_vision_node_B.b_s_data[qq_tmp];
        erc_vision_node_B.b_s_data[qq_tmp] *= erc_vision_node_B.sqds;
        qjj = (qq_tmp - 1) * 3 + 1;
        kase = 3 * qq_tmp + 1;
        erc_vision_node_xrot(V_data, qjj, kase, erc_vision_node_B.sqds,
                             erc_vision_node_B.smm1_l);
        erc_vision_node_B.b_s_data[qq_tmp - 1] = erc_vision_node_B.emm1_j *
          erc_vision_node_B.sqds + erc_vision_node_B.r_p *
          erc_vision_node_B.smm1_l;
        erc_vision_node_xrotg(&erc_vision_node_B.b_s_data[qq_tmp - 1],
                              &erc_vision_node_B.rt_n, &erc_vision_node_B.sqds,
                              &erc_vision_node_B.smm1_l);
        erc_vision_node_B.r_p = erc_vision_node_B.e_data_c[qq_tmp - 1];
        erc_vision_node_B.rt_n = erc_vision_node_B.r_p * erc_vision_node_B.sqds
          + erc_vision_node_B.smm1_l * erc_vision_node_B.b_s_data[qq_tmp];
        erc_vision_node_B.b_s_data[qq_tmp] = erc_vision_node_B.r_p *
          -erc_vision_node_B.smm1_l + erc_vision_node_B.sqds *
          erc_vision_node_B.b_s_data[qq_tmp];
        erc_vision_node_B.r_p = erc_vision_node_B.smm1_l *
          erc_vision_node_B.e_data_c[qq_tmp];
        erc_vision_node_B.e_data_c[qq_tmp] *= erc_vision_node_B.sqds;
        erc_vision_node_xrot(U_data, qjj, kase, erc_vision_node_B.sqds,
                             erc_vision_node_B.smm1_l);
      }

      erc_vision_node_B.e_data_c[m] = erc_vision_node_B.rt_n;
      qp1++;
      break;

     default:
      if (erc_vision_node_B.b_s_data[qq] < 0.0) {
        erc_vision_node_B.b_s_data[qq] = -erc_vision_node_B.b_s_data[qq];
        qp1 = 3 * qq + 1;
        for (qjj = qp1; qjj <= qp1 + 2; qjj++) {
          V_data[qjj - 1] = -V_data[qjj - 1];
        }
      }

      qp1 = qq + 1;
      while ((qq + 1 < 3) && (erc_vision_node_B.b_s_data[qq] <
                              erc_vision_node_B.b_s_data[qp1])) {
        erc_vision_node_B.rt_n = erc_vision_node_B.b_s_data[qq];
        erc_vision_node_B.b_s_data[qq] = erc_vision_node_B.b_s_data[qp1];
        erc_vision_node_B.b_s_data[qp1] = erc_vision_node_B.rt_n;
        qjj = 3 * qq + 1;
        kase = (qq + 1) * 3 + 1;
        erc_vision_node_xswap(V_data, qjj, kase);
        erc_vision_node_xswap(U_data, qjj, kase);
        qq = qp1;
        qp1++;
      }

      qp1 = 0;
      m--;
      break;
    }
  }

  *s_size = 3;
  s_data[0] = erc_vision_node_B.b_s_data[0];
  s_data[1] = erc_vision_node_B.b_s_data[1];
  s_data[2] = erc_vision_node_B.b_s_data[2];
  if (doscale) {
    erc_vision_node_B.i_data[0] = erc_vision_node_B.b_s_data[0];
    erc_vision_node_B.i_data[1] = erc_vision_node_B.b_s_data[1];
    erc_vision_node_B.i_data[2] = erc_vision_node_B.b_s_data[2];
    erc_vision_node_xzlascl_j(erc_vision_node_B.cscale_g,
      erc_vision_node_B.anrm_g, 3, erc_vision_node_B.i_data);
    *s_size = 3;
    memcpy(&s_data[0], &erc_vision_node_B.i_data[0], 3U * sizeof(real_T));
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_svd_f(const real_T A_data[], real_T
  U_data[], int32_T *U_size)
{
  int32_T h;
  int32_T m;
  int32_T qjj;
  int32_T qp1;
  int32_T qq;
  int32_T qq_tmp;
  int32_T qs;
  boolean_T apply_transform;
  boolean_T doscale;
  boolean_T exitg1;
  memcpy(&erc_vision_node_B.b_A_data[0], &A_data[0], 9U * sizeof(real_T));
  erc_vision_node_B.s_data_p[0] = 0.0;
  erc_vision_node_B.e_data[0] = 0.0;
  erc_vision_node_B.work_data[0] = 0.0;
  erc_vision_node_B.s_data_p[1] = 0.0;
  erc_vision_node_B.e_data[1] = 0.0;
  erc_vision_node_B.work_data[1] = 0.0;
  erc_vision_node_B.s_data_p[2] = 0.0;
  erc_vision_node_B.e_data[2] = 0.0;
  erc_vision_node_B.work_data[2] = 0.0;
  doscale = false;
  erc_vision_node_B.anrm = erc_vision_node_xzlangeM(A_data);
  erc_vision_node_B.cscale = erc_vision_node_B.anrm;
  if ((erc_vision_node_B.anrm > 0.0) && (erc_vision_node_B.anrm <
       6.717876107567089E-139)) {
    doscale = true;
    erc_vision_node_B.cscale = 6.717876107567089E-139;
    erc_vision_node_xzlascl(erc_vision_node_B.anrm, erc_vision_node_B.cscale,
      erc_vision_node_B.b_A_data);
  } else if (erc_vision_node_B.anrm > 1.488565707357403E+138) {
    doscale = true;
    erc_vision_node_B.cscale = 1.488565707357403E+138;
    erc_vision_node_xzlascl(erc_vision_node_B.anrm, erc_vision_node_B.cscale,
      erc_vision_node_B.b_A_data);
  }

  for (m = 0; m < 2; m++) {
    qp1 = m + 2;
    qq_tmp = 3 * m + m;
    qq = qq_tmp + 1;
    apply_transform = false;
    erc_vision_node_B.nrm = erc_vision_node_xnrm2(3 - m,
      erc_vision_node_B.b_A_data, qq_tmp + 1);
    if (erc_vision_node_B.nrm > 0.0) {
      apply_transform = true;
      if (erc_vision_node_B.b_A_data[qq_tmp] < 0.0) {
        erc_vision_node_B.nrm = -erc_vision_node_B.nrm;
      }

      erc_vision_node_B.s_data_p[m] = erc_vision_node_B.nrm;
      if (fabs(erc_vision_node_B.nrm) >= 1.0020841800044864E-292) {
        erc_vision_node_B.nrm = 1.0 / erc_vision_node_B.nrm;
        qs = (qq_tmp - m) + 3;
        for (qjj = qq; qjj <= qs; qjj++) {
          erc_vision_node_B.b_A_data[qjj - 1] *= erc_vision_node_B.nrm;
        }
      } else {
        qs = (qq_tmp - m) + 3;
        for (qjj = qq; qjj <= qs; qjj++) {
          erc_vision_node_B.b_A_data[qjj - 1] /= erc_vision_node_B.s_data_p[m];
        }
      }

      erc_vision_node_B.b_A_data[qq_tmp]++;
      erc_vision_node_B.s_data_p[m] = -erc_vision_node_B.s_data_p[m];
    } else {
      erc_vision_node_B.s_data_p[m] = 0.0;
    }

    for (qs = qp1; qs < 4; qs++) {
      qjj = (qs - 1) * 3 + m;
      if (apply_transform) {
        erc_vision_node_B.nrm = 0.0;
        h = 2 - m;
        for (qq = 0; qq <= h; qq++) {
          erc_vision_node_B.nrm += erc_vision_node_B.b_A_data[qq_tmp + qq] *
            erc_vision_node_B.b_A_data[qjj + qq];
        }

        erc_vision_node_xaxpy(3 - m, -(erc_vision_node_B.nrm /
          erc_vision_node_B.b_A_data[qq_tmp]), qq_tmp + 1,
                              erc_vision_node_B.b_A_data, qjj + 1);
      }

      erc_vision_node_B.e_data[qs - 1] = erc_vision_node_B.b_A_data[qjj];
    }

    if (m <= 0) {
      erc_vision_node_B.nrm = erc_vision_node_xnrm2_o(erc_vision_node_B.e_data,
        2);
      if (erc_vision_node_B.nrm == 0.0) {
        erc_vision_node_B.e_data[0] = 0.0;
      } else {
        if (erc_vision_node_B.e_data[1] < 0.0) {
          erc_vision_node_B.e_data[0] = -erc_vision_node_B.nrm;
        } else {
          erc_vision_node_B.e_data[0] = erc_vision_node_B.nrm;
        }

        erc_vision_node_B.nrm = erc_vision_node_B.e_data[0];
        if (fabs(erc_vision_node_B.e_data[0]) >= 1.0020841800044864E-292) {
          erc_vision_node_B.nrm = 1.0 / erc_vision_node_B.e_data[0];
          for (qq = qp1; qq < 4; qq++) {
            erc_vision_node_B.e_data[qq - 1] *= erc_vision_node_B.nrm;
          }
        } else {
          for (qq = qp1; qq < 4; qq++) {
            erc_vision_node_B.e_data[qq - 1] /= erc_vision_node_B.nrm;
          }
        }

        erc_vision_node_B.e_data[1]++;
        erc_vision_node_B.e_data[0] = -erc_vision_node_B.e_data[0];
        for (qq = qp1; qq < 4; qq++) {
          erc_vision_node_B.work_data[qq - 1] = 0.0;
        }

        for (qq = qp1; qq < 4; qq++) {
          erc_vision_node_xaxpy_m(2, erc_vision_node_B.e_data[qq - 1],
            erc_vision_node_B.b_A_data, 3 * (qq - 1) + 2,
            erc_vision_node_B.work_data, 2);
        }

        for (qq = qp1; qq < 4; qq++) {
          erc_vision_node_xaxpy_ms(2, -erc_vision_node_B.e_data[qq - 1] /
            erc_vision_node_B.e_data[1], erc_vision_node_B.work_data, 2,
            erc_vision_node_B.b_A_data, 3 * (qq - 1) + 2);
        }
      }
    }
  }

  m = 1;
  erc_vision_node_B.s_data_p[2] = erc_vision_node_B.b_A_data[8];
  erc_vision_node_B.e_data[1] = erc_vision_node_B.b_A_data[7];
  erc_vision_node_B.e_data[2] = 0.0;
  qp1 = 0;
  erc_vision_node_B.nrm = 0.0;
  erc_vision_node_B.ztest = erc_vision_node_B.s_data_p[0];
  if (erc_vision_node_B.s_data_p[0] != 0.0) {
    erc_vision_node_B.rt = fabs(erc_vision_node_B.s_data_p[0]);
    erc_vision_node_B.r = erc_vision_node_B.s_data_p[0] / erc_vision_node_B.rt;
    erc_vision_node_B.ztest = erc_vision_node_B.rt;
    erc_vision_node_B.s_data_p[0] = erc_vision_node_B.rt;
    erc_vision_node_B.e_data[0] /= erc_vision_node_B.r;
  }

  if (erc_vision_node_B.e_data[0] != 0.0) {
    erc_vision_node_B.rt = fabs(erc_vision_node_B.e_data[0]);
    erc_vision_node_B.r = erc_vision_node_B.rt / erc_vision_node_B.e_data[0];
    erc_vision_node_B.e_data[0] = erc_vision_node_B.rt;
    erc_vision_node_B.s_data_p[1] *= erc_vision_node_B.r;
  }

  erc_vision_node_B.rt = fabs(erc_vision_node_B.e_data[0]);
  if ((erc_vision_node_B.ztest >= erc_vision_node_B.rt) || rtIsNaN
      (erc_vision_node_B.rt)) {
    erc_vision_node_B.rt = erc_vision_node_B.ztest;
  }

  if (!(erc_vision_node_B.rt <= 0.0) && !rtIsNaN(erc_vision_node_B.rt)) {
    erc_vision_node_B.nrm = erc_vision_node_B.rt;
  }

  erc_vision_node_B.ztest = erc_vision_node_B.s_data_p[1];
  if (erc_vision_node_B.s_data_p[1] != 0.0) {
    erc_vision_node_B.rt = fabs(erc_vision_node_B.s_data_p[1]);
    erc_vision_node_B.r = erc_vision_node_B.s_data_p[1] / erc_vision_node_B.rt;
    erc_vision_node_B.ztest = erc_vision_node_B.rt;
    erc_vision_node_B.s_data_p[1] = erc_vision_node_B.rt;
    erc_vision_node_B.e_data[1] /= erc_vision_node_B.r;
  }

  if (erc_vision_node_B.e_data[1] != 0.0) {
    erc_vision_node_B.rt = fabs(erc_vision_node_B.e_data[1]);
    erc_vision_node_B.r = erc_vision_node_B.rt / erc_vision_node_B.e_data[1];
    erc_vision_node_B.e_data[1] = erc_vision_node_B.rt;
    erc_vision_node_B.s_data_p[2] *= erc_vision_node_B.r;
  }

  erc_vision_node_B.rt = fabs(erc_vision_node_B.e_data[1]);
  if ((erc_vision_node_B.ztest >= erc_vision_node_B.rt) || rtIsNaN
      (erc_vision_node_B.rt)) {
    erc_vision_node_B.rt = erc_vision_node_B.ztest;
  }

  if (!(erc_vision_node_B.nrm >= erc_vision_node_B.rt) && !rtIsNaN
      (erc_vision_node_B.rt)) {
    erc_vision_node_B.nrm = erc_vision_node_B.rt;
  }

  erc_vision_node_B.ztest = erc_vision_node_B.s_data_p[2];
  if (erc_vision_node_B.s_data_p[2] != 0.0) {
    erc_vision_node_B.rt = fabs(erc_vision_node_B.s_data_p[2]);
    erc_vision_node_B.ztest = erc_vision_node_B.rt;
    erc_vision_node_B.s_data_p[2] = erc_vision_node_B.rt;
  }

  erc_vision_node_B.rt = fabs(0.0);
  if ((erc_vision_node_B.ztest >= erc_vision_node_B.rt) || rtIsNaN
      (erc_vision_node_B.rt)) {
    erc_vision_node_B.rt = erc_vision_node_B.ztest;
  }

  if (!(erc_vision_node_B.nrm >= erc_vision_node_B.rt) && !rtIsNaN
      (erc_vision_node_B.rt)) {
    erc_vision_node_B.nrm = erc_vision_node_B.rt;
  }

  while ((m + 2 > 0) && (qp1 < 75)) {
    qq = m + 1;
    exitg1 = false;
    while (!(exitg1 || (qq == 0))) {
      erc_vision_node_B.rt = fabs(erc_vision_node_B.e_data[qq - 1]);
      if (erc_vision_node_B.rt <= (fabs(erc_vision_node_B.s_data_p[qq - 1]) +
           fabs(erc_vision_node_B.s_data_p[qq])) * 2.220446049250313E-16) {
        erc_vision_node_B.e_data[qq - 1] = 0.0;
        exitg1 = true;
      } else if ((erc_vision_node_B.rt <= 1.0020841800044864E-292) || ((qp1 > 20)
                  && (erc_vision_node_B.rt <= 2.220446049250313E-16 *
                      erc_vision_node_B.nrm))) {
        erc_vision_node_B.e_data[qq - 1] = 0.0;
        exitg1 = true;
      } else {
        qq--;
      }
    }

    if (m + 1 == qq) {
      qjj = 4;
    } else {
      qs = m + 2;
      qjj = m + 2;
      exitg1 = false;
      while (!exitg1 && (qjj >= qq)) {
        qs = qjj;
        if (qjj == qq) {
          exitg1 = true;
        } else {
          erc_vision_node_B.rt = 0.0;
          if (qjj < m + 2) {
            erc_vision_node_B.rt = fabs(erc_vision_node_B.e_data[qjj - 1]);
          }

          if (qjj > qq + 1) {
            erc_vision_node_B.rt += fabs(erc_vision_node_B.e_data[qjj - 2]);
          }

          erc_vision_node_B.ztest = fabs(erc_vision_node_B.s_data_p[qjj - 1]);
          if ((erc_vision_node_B.ztest <= 2.220446049250313E-16 *
               erc_vision_node_B.rt) || (erc_vision_node_B.ztest <=
               1.0020841800044864E-292)) {
            erc_vision_node_B.s_data_p[qjj - 1] = 0.0;
            exitg1 = true;
          } else {
            qjj--;
          }
        }
      }

      if (qs == qq) {
        qjj = 3;
      } else if (m + 2 == qs) {
        qjj = 1;
      } else {
        qjj = 2;
        qq = qs;
      }
    }

    switch (qjj) {
     case 1:
      erc_vision_node_B.rt = erc_vision_node_B.e_data[m];
      erc_vision_node_B.e_data[m] = 0.0;
      for (qs = m + 1; qs >= qq + 1; qs--) {
        erc_vision_node_xrotg(&erc_vision_node_B.s_data_p[qs - 1],
                              &erc_vision_node_B.rt, &erc_vision_node_B.ztest,
                              &erc_vision_node_B.r);
        if (qs > qq + 1) {
          erc_vision_node_B.rt = -erc_vision_node_B.r *
            erc_vision_node_B.e_data[0];
          erc_vision_node_B.e_data[0] *= erc_vision_node_B.ztest;
        }
      }
      break;

     case 2:
      erc_vision_node_B.rt = erc_vision_node_B.e_data[qq - 1];
      erc_vision_node_B.e_data[qq - 1] = 0.0;
      for (qs = qq + 1; qs <= m + 2; qs++) {
        erc_vision_node_xrotg(&erc_vision_node_B.s_data_p[qs - 1],
                              &erc_vision_node_B.rt, &erc_vision_node_B.ztest,
                              &erc_vision_node_B.r);
        erc_vision_node_B.smm1 = erc_vision_node_B.e_data[qs - 1];
        erc_vision_node_B.rt = -erc_vision_node_B.r * erc_vision_node_B.smm1;
        erc_vision_node_B.e_data[qs - 1] = erc_vision_node_B.smm1 *
          erc_vision_node_B.ztest;
      }
      break;

     case 3:
      erc_vision_node_B.r = erc_vision_node_B.s_data_p[m + 1];
      erc_vision_node_B.ztest = fabs(erc_vision_node_B.r);
      erc_vision_node_B.rt = fabs(erc_vision_node_B.s_data_p[m]);
      if ((erc_vision_node_B.ztest >= erc_vision_node_B.rt) || rtIsNaN
          (erc_vision_node_B.rt)) {
        erc_vision_node_B.rt = erc_vision_node_B.ztest;
      }

      erc_vision_node_B.ztest = fabs(erc_vision_node_B.e_data[m]);
      if ((erc_vision_node_B.rt >= erc_vision_node_B.ztest) || rtIsNaN
          (erc_vision_node_B.ztest)) {
        erc_vision_node_B.ztest = erc_vision_node_B.rt;
      }

      erc_vision_node_B.rt = fabs(erc_vision_node_B.s_data_p[qq]);
      if ((erc_vision_node_B.ztest >= erc_vision_node_B.rt) || rtIsNaN
          (erc_vision_node_B.rt)) {
        erc_vision_node_B.rt = erc_vision_node_B.ztest;
      }

      erc_vision_node_B.ztest = fabs(erc_vision_node_B.e_data[qq]);
      if ((erc_vision_node_B.rt >= erc_vision_node_B.ztest) || rtIsNaN
          (erc_vision_node_B.ztest)) {
        erc_vision_node_B.ztest = erc_vision_node_B.rt;
      }

      erc_vision_node_B.rt = erc_vision_node_B.r / erc_vision_node_B.ztest;
      erc_vision_node_B.smm1 = erc_vision_node_B.s_data_p[m] /
        erc_vision_node_B.ztest;
      erc_vision_node_B.emm1 = erc_vision_node_B.e_data[m] /
        erc_vision_node_B.ztest;
      erc_vision_node_B.r = erc_vision_node_B.s_data_p[qq] /
        erc_vision_node_B.ztest;
      erc_vision_node_B.smm1 = ((erc_vision_node_B.smm1 + erc_vision_node_B.rt) *
        (erc_vision_node_B.smm1 - erc_vision_node_B.rt) + erc_vision_node_B.emm1
        * erc_vision_node_B.emm1) / 2.0;
      erc_vision_node_B.emm1 *= erc_vision_node_B.rt;
      erc_vision_node_B.emm1 *= erc_vision_node_B.emm1;
      if ((erc_vision_node_B.smm1 != 0.0) || (erc_vision_node_B.emm1 != 0.0)) {
        erc_vision_node_B.shift = sqrt(erc_vision_node_B.smm1 *
          erc_vision_node_B.smm1 + erc_vision_node_B.emm1);
        if (erc_vision_node_B.smm1 < 0.0) {
          erc_vision_node_B.shift = -erc_vision_node_B.shift;
        }

        erc_vision_node_B.shift = erc_vision_node_B.emm1 /
          (erc_vision_node_B.smm1 + erc_vision_node_B.shift);
      } else {
        erc_vision_node_B.shift = 0.0;
      }

      erc_vision_node_B.rt = (erc_vision_node_B.r + erc_vision_node_B.rt) *
        (erc_vision_node_B.r - erc_vision_node_B.rt) + erc_vision_node_B.shift;
      erc_vision_node_B.ztest = erc_vision_node_B.e_data[qq] /
        erc_vision_node_B.ztest * erc_vision_node_B.r;
      for (qs = qq + 1; qs <= m + 1; qs++) {
        erc_vision_node_xrotg(&erc_vision_node_B.rt, &erc_vision_node_B.ztest,
                              &erc_vision_node_B.r, &erc_vision_node_B.smm1);
        if (qs > qq + 1) {
          erc_vision_node_B.e_data[0] = erc_vision_node_B.rt;
        }

        erc_vision_node_B.ztest = erc_vision_node_B.e_data[qs - 1];
        erc_vision_node_B.emm1 = erc_vision_node_B.s_data_p[qs - 1];
        erc_vision_node_B.e_data[qs - 1] = erc_vision_node_B.ztest *
          erc_vision_node_B.r - erc_vision_node_B.emm1 * erc_vision_node_B.smm1;
        erc_vision_node_B.rt = erc_vision_node_B.smm1 *
          erc_vision_node_B.s_data_p[qs];
        erc_vision_node_B.s_data_p[qs] *= erc_vision_node_B.r;
        erc_vision_node_B.s_data_p[qs - 1] = erc_vision_node_B.emm1 *
          erc_vision_node_B.r + erc_vision_node_B.ztest * erc_vision_node_B.smm1;
        erc_vision_node_xrotg(&erc_vision_node_B.s_data_p[qs - 1],
                              &erc_vision_node_B.rt, &erc_vision_node_B.r,
                              &erc_vision_node_B.smm1);
        erc_vision_node_B.ztest = erc_vision_node_B.e_data[qs - 1];
        erc_vision_node_B.rt = erc_vision_node_B.ztest * erc_vision_node_B.r +
          erc_vision_node_B.smm1 * erc_vision_node_B.s_data_p[qs];
        erc_vision_node_B.s_data_p[qs] = erc_vision_node_B.ztest *
          -erc_vision_node_B.smm1 + erc_vision_node_B.r *
          erc_vision_node_B.s_data_p[qs];
        erc_vision_node_B.ztest = erc_vision_node_B.smm1 *
          erc_vision_node_B.e_data[qs];
        erc_vision_node_B.e_data[qs] *= erc_vision_node_B.r;
      }

      erc_vision_node_B.e_data[m] = erc_vision_node_B.rt;
      qp1++;
      break;

     default:
      if (erc_vision_node_B.s_data_p[qq] < 0.0) {
        erc_vision_node_B.s_data_p[qq] = -erc_vision_node_B.s_data_p[qq];
      }

      qp1 = qq + 1;
      while ((qq + 1 < 3) && (erc_vision_node_B.s_data_p[qq] <
                              erc_vision_node_B.s_data_p[qp1])) {
        erc_vision_node_B.rt = erc_vision_node_B.s_data_p[qq];
        erc_vision_node_B.s_data_p[qq] = erc_vision_node_B.s_data_p[qp1];
        erc_vision_node_B.s_data_p[qp1] = erc_vision_node_B.rt;
        qq = qp1;
        qp1++;
      }

      qp1 = 0;
      m--;
      break;
    }
  }

  *U_size = 3;
  U_data[0] = erc_vision_node_B.s_data_p[0];
  U_data[1] = erc_vision_node_B.s_data_p[1];
  U_data[2] = erc_vision_node_B.s_data_p[2];
  if (doscale) {
    erc_vision_node_B.j_data[0] = erc_vision_node_B.s_data_p[0];
    erc_vision_node_B.j_data[1] = erc_vision_node_B.s_data_p[1];
    erc_vision_node_B.j_data[2] = erc_vision_node_B.s_data_p[2];
    erc_vision_node_xzlascl_j(erc_vision_node_B.cscale, erc_vision_node_B.anrm,
      3, erc_vision_node_B.j_data);
    *U_size = 3;
    memcpy(&U_data[0], &erc_vision_node_B.j_data[0], 3U * sizeof(real_T));
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
real_T erc_vision_node::erc_vision_node_norm(const real_T x_data[])
{
  real_T y;
  int32_T j;
  y = 0.0;
  for (j = 0; j < 3; j++) {
    erc_vision_node_B.absx = fabs(x_data[3 * j]);
    if (rtIsNaN(erc_vision_node_B.absx)) {
      y = (rtNaN);
    } else if (erc_vision_node_B.absx > y) {
      y = erc_vision_node_B.absx;
    }

    erc_vision_node_B.absx = fabs(x_data[3 * j + 1]);
    if (rtIsNaN(erc_vision_node_B.absx)) {
      y = (rtNaN);
    } else if (erc_vision_node_B.absx > y) {
      y = erc_vision_node_B.absx;
    }

    erc_vision_node_B.absx = fabs(x_data[3 * j + 2]);
    if (rtIsNaN(erc_vision_node_B.absx)) {
      y = (rtNaN);
    } else if (erc_vision_node_B.absx > y) {
      y = erc_vision_node_B.absx;
    }
  }

  if (!rtIsInf(y) && !rtIsNaN(y)) {
    erc_vision_node_svd_f(x_data, erc_vision_node_B.tmp_data, &j);
    y = erc_vision_node_B.tmp_data[0];
  }

  return y;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_constrainToRotationMatrix3D(const real_T R_data[],
  real_T Rc_data[], int32_T Rc_size[2])
{
  int8_T ipiv_data[3];
  boolean_T isodd;
  for (erc_vision_node_B.yk = 0; erc_vision_node_B.yk < 9; erc_vision_node_B.yk
       ++) {
    erc_vision_node_B.smax = R_data[erc_vision_node_B.yk];
    if (!(erc_vision_node_B.smax <= 1.0)) {
      erc_vision_node_B.smax = 1.0;
    }

    if (!(erc_vision_node_B.smax >= -1.0)) {
      erc_vision_node_B.smax = -1.0;
    }

    erc_vision_node_B.R_clamped_data[erc_vision_node_B.yk] =
      erc_vision_node_B.smax;
  }

  erc_vision_node_svd(erc_vision_node_B.R_clamped_data, erc_vision_node_B.y_data,
                      erc_vision_node_B.y_size, erc_vision_node_B.s_data,
                      &erc_vision_node_B.s_size, erc_vision_node_B.b_data,
                      erc_vision_node_B.b_size);
  Rc_size[0] = 3;
  Rc_size[1] = 3;
  for (erc_vision_node_B.yk = 0; erc_vision_node_B.yk < 3; erc_vision_node_B.yk
       ++) {
    erc_vision_node_B.smax = 0.0;
    erc_vision_node_B.b_s = 0.0;
    erc_vision_node_B.Rc = 0.0;
    for (erc_vision_node_B.f_k = 0; erc_vision_node_B.f_k < 3;
         erc_vision_node_B.f_k++) {
      erc_vision_node_B.d = erc_vision_node_B.b_data[3 * erc_vision_node_B.f_k +
        erc_vision_node_B.yk];
      erc_vision_node_B.smax += erc_vision_node_B.y_data[3 *
        erc_vision_node_B.f_k] * erc_vision_node_B.d;
      erc_vision_node_B.b_s += erc_vision_node_B.y_data[3 *
        erc_vision_node_B.f_k + 1] * erc_vision_node_B.d;
      erc_vision_node_B.Rc += erc_vision_node_B.y_data[3 * erc_vision_node_B.f_k
        + 2] * erc_vision_node_B.d;
    }

    Rc_data[3 * erc_vision_node_B.yk + 2] = erc_vision_node_B.Rc;
    Rc_data[3 * erc_vision_node_B.yk + 1] = erc_vision_node_B.b_s;
    Rc_data[3 * erc_vision_node_B.yk] = erc_vision_node_B.smax;
  }

  memcpy(&erc_vision_node_B.y_data[0], &Rc_data[0], 9U * sizeof(real_T));
  erc_vision_node_B.ipiv_data_tmp = 0;
  ipiv_data[erc_vision_node_B.ipiv_data_tmp] = 1;
  erc_vision_node_B.yk = 1;
  for (erc_vision_node_B.f_k = 0; erc_vision_node_B.f_k < 2;
       erc_vision_node_B.f_k++) {
    erc_vision_node_B.yk++;
    ipiv_data[erc_vision_node_B.f_k + 1] = static_cast<int8_T>
      (erc_vision_node_B.yk);
    erc_vision_node_B.jj = erc_vision_node_B.f_k << 2;
    erc_vision_node_B.jA = 4 - erc_vision_node_B.f_k;
    erc_vision_node_B.a = 0;
    erc_vision_node_B.smax = fabs(erc_vision_node_B.y_data[erc_vision_node_B.jj]);
    for (erc_vision_node_B.d_k = 2; erc_vision_node_B.d_k < erc_vision_node_B.jA;
         erc_vision_node_B.d_k++) {
      erc_vision_node_B.b_s = fabs(erc_vision_node_B.y_data
        [(erc_vision_node_B.jj + erc_vision_node_B.d_k) - 1]);
      if (erc_vision_node_B.b_s > erc_vision_node_B.smax) {
        erc_vision_node_B.a = erc_vision_node_B.d_k - 1;
        erc_vision_node_B.smax = erc_vision_node_B.b_s;
      }
    }

    if (erc_vision_node_B.y_data[erc_vision_node_B.jj + erc_vision_node_B.a] !=
        0.0) {
      if (erc_vision_node_B.a != 0) {
        erc_vision_node_B.jA = erc_vision_node_B.f_k + erc_vision_node_B.a;
        ipiv_data[erc_vision_node_B.f_k] = static_cast<int8_T>
          (erc_vision_node_B.jA + 1);
        erc_vision_node_B.smax = erc_vision_node_B.y_data[erc_vision_node_B.f_k];
        erc_vision_node_B.y_data[erc_vision_node_B.f_k] =
          erc_vision_node_B.y_data[erc_vision_node_B.jA];
        erc_vision_node_B.y_data[erc_vision_node_B.jA] = erc_vision_node_B.smax;
        erc_vision_node_B.smax = erc_vision_node_B.y_data[erc_vision_node_B.f_k
          + 3];
        erc_vision_node_B.y_data[erc_vision_node_B.f_k + 3] =
          erc_vision_node_B.y_data[erc_vision_node_B.jA + 3];
        erc_vision_node_B.y_data[erc_vision_node_B.jA + 3] =
          erc_vision_node_B.smax;
        erc_vision_node_B.smax = erc_vision_node_B.y_data[erc_vision_node_B.f_k
          + 6];
        erc_vision_node_B.y_data[erc_vision_node_B.f_k + 6] =
          erc_vision_node_B.y_data[erc_vision_node_B.jA + 6];
        erc_vision_node_B.y_data[erc_vision_node_B.jA + 6] =
          erc_vision_node_B.smax;
      }

      erc_vision_node_B.jA = (erc_vision_node_B.jj - erc_vision_node_B.f_k) + 3;
      for (erc_vision_node_B.a = erc_vision_node_B.jj + 2; erc_vision_node_B.a <=
           erc_vision_node_B.jA; erc_vision_node_B.a++) {
        erc_vision_node_B.y_data[erc_vision_node_B.a - 1] /=
          erc_vision_node_B.y_data[erc_vision_node_B.jj];
      }
    }

    erc_vision_node_B.jA = erc_vision_node_B.jj + 5;
    erc_vision_node_B.a = 1 - erc_vision_node_B.f_k;
    for (erc_vision_node_B.d_k = 0; erc_vision_node_B.d_k <= erc_vision_node_B.a;
         erc_vision_node_B.d_k++) {
      erc_vision_node_B.smax = erc_vision_node_B.y_data[(erc_vision_node_B.d_k *
        3 + erc_vision_node_B.jj) + 3];
      if (erc_vision_node_B.smax != 0.0) {
        erc_vision_node_B.e = (erc_vision_node_B.jA - erc_vision_node_B.f_k) + 1;
        for (erc_vision_node_B.ijA = erc_vision_node_B.jA; erc_vision_node_B.ijA
             <= erc_vision_node_B.e; erc_vision_node_B.ijA++) {
          erc_vision_node_B.y_data[erc_vision_node_B.ijA - 1] +=
            erc_vision_node_B.y_data[((erc_vision_node_B.jj +
            erc_vision_node_B.ijA) - erc_vision_node_B.jA) + 1] *
            -erc_vision_node_B.smax;
        }
      }

      erc_vision_node_B.jA += 3;
    }
  }

  isodd = (ipiv_data[erc_vision_node_B.ipiv_data_tmp] > 1);
  erc_vision_node_B.smax = erc_vision_node_B.y_data[0] *
    erc_vision_node_B.y_data[4] * erc_vision_node_B.y_data[8];
  if (ipiv_data[1] > 2) {
    isodd = !isodd;
  }

  if (isodd) {
    erc_vision_node_B.smax = -erc_vision_node_B.smax;
  }

  if (erc_vision_node_B.smax < 0.0) {
    for (erc_vision_node_B.yk = 0; erc_vision_node_B.yk < 3;
         erc_vision_node_B.yk++) {
      erc_vision_node_B.f_k = 3 * erc_vision_node_B.yk;
      erc_vision_node_B.smax = Rc_data[erc_vision_node_B.f_k];
      erc_vision_node_B.a = 3 * erc_vision_node_B.yk + 1;
      Rc_data[erc_vision_node_B.f_k] = Rc_data[erc_vision_node_B.a];
      Rc_data[erc_vision_node_B.a] = erc_vision_node_B.smax;
    }
  }

  for (erc_vision_node_B.yk = 0; erc_vision_node_B.yk < 9; erc_vision_node_B.yk
       ++) {
    erc_vision_node_B.y_data[erc_vision_node_B.yk] =
      erc_vision_node_B.R_clamped_data[erc_vision_node_B.yk] -
      Rc_data[erc_vision_node_B.yk];
  }

  if (erc_vision_node_norm(erc_vision_node_B.y_data) / 2.220446049250313E-16 <
      10.0) {
    Rc_size[0] = 3;
    Rc_size[1] = 3;
    memcpy(&Rc_data[0], &erc_vision_node_B.R_clamped_data[0], 9U * sizeof(real_T));
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_v_rigidtform3d_rigidtform3d(const real_T
  varargin_1_data[], const real_T varargin_2_data[], real_T
  b_this_Translation_data[], int32_T b_this_Translation_size[2], real_T
  b_this_R_data[], int32_T b_this_R_size[2], coder::array<
  c_images_geotrans_internal_ri_T, 2U> &b_this_Data)
{
  erc_constrainToRotationMatrix3D(varargin_1_data, b_this_R_data, b_this_R_size);
  b_this_Translation_size[0] = 1;
  b_this_Translation_size[1] = 3;
  erc_vision_node_B.i_b = 0;
  b_this_Translation_data[erc_vision_node_B.i_b] = varargin_2_data[0];
  erc_vision_node_B.i1 = 1;
  b_this_Translation_data[erc_vision_node_B.i1] = varargin_2_data[1];
  erc_vision_node_B.i2 = 2;
  b_this_Translation_data[erc_vision_node_B.i2] = varargin_2_data[2];
  erc_vision_node_B.b.R.size[0] = 3;
  erc_vision_node_B.b.R.size[1] = 3;
  memcpy(&erc_vision_node_B.b.R.data[0], &b_this_R_data[0], 9U * sizeof(real_T));
  erc_vision_node_B.b.Translation.size[0] = 1;
  erc_vision_node_B.b.Translation.size[1] = 3;
  erc_vision_node_B.b.Translation.data[erc_vision_node_B.i_b] = varargin_2_data
    [0];
  erc_vision_node_B.b.Translation.data[erc_vision_node_B.i1] = varargin_2_data[1];
  erc_vision_node_B.b.Translation.data[erc_vision_node_B.i2] = varargin_2_data[2];
  b_this_Data.set_size(1, 1);
  b_this_Data[erc_vision_node_B.i_b] = erc_vision_node_B.b;
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::erc_vision_node_readArucoMarker(const uint8_T b_I[921600],
  const cameraIntrinsics_erc_vision_n_T *varargin_2, coder::array<real_T, 2U>
  &varargout_1, coder::array<real_T, 3U> &varargout_2, coder::array<
  c_images_geotrans_internal_ri_T, 2U> &varargout_3_Data)
{
  void *detectionsObj;
  static const char_T b_markersProc[20] = "DICT_ARUCO_ORIGINAL";
  memcpy(&erc_vision_node_B.c_I[0], &b_I[0], 921600U * sizeof(uint8_T));
  for (erc_vision_node_B.rejectionLength = 0; erc_vision_node_B.rejectionLength <
       5; erc_vision_node_B.rejectionLength++) {
    erc_vision_node_B.distCoeffs[erc_vision_node_B.rejectionLength] = 0.0;
  }

  erc_vision_node_B.distCoeffs[0] = varargin_2->RadialDistortion[0];
  erc_vision_node_B.distCoeffs[2] = varargin_2->TangentialDistortion[0];
  erc_vision_node_B.distCoeffs[1] = varargin_2->RadialDistortion[1];
  erc_vision_node_B.distCoeffs[3] = varargin_2->TangentialDistortion[1];
  erc_vision_node_B.camMatrix[0] = varargin_2->FocalLength[0];
  erc_vision_node_B.camMatrix[1] = 0.0;
  erc_vision_node_B.camMatrix[2] = varargin_2->PrincipalPoint[0] - 1.0;
  erc_vision_node_B.camMatrix[3] = 0.0;
  erc_vision_node_B.camMatrix[4] = varargin_2->FocalLength[1];
  erc_vision_node_B.camMatrix[5] = varargin_2->PrincipalPoint[1] - 1.0;
  erc_vision_node_B.camMatrix[6] = 0.0;
  erc_vision_node_B.camMatrix[7] = 0.0;
  erc_vision_node_B.camMatrix[8] = 1.0;
  erc_vision_node_B.markersLength[0] = 19;
  erc_vision_node_B.markersLength[1] = 0;
  for (erc_vision_node_B.rejectionLength = 0; erc_vision_node_B.rejectionLength <
       20; erc_vision_node_B.rejectionLength++) {
    erc_vision_node_B.markersProc[erc_vision_node_B.rejectionLength] =
      b_markersProc[erc_vision_node_B.rejectionLength];
  }

  erc_vision_node_B.b_m.adaptiveThreshWinSizeMin = 3;
  erc_vision_node_B.b_m.adaptiveThreshWinSizeMax = 23;
  erc_vision_node_B.b_m.adaptiveThreshWinSizeStep = 10;
  erc_vision_node_B.b_m.adaptiveThreshConstant = 7.0;
  erc_vision_node_B.b_m.minMarkerPerimeterRate = 0.03;
  erc_vision_node_B.b_m.maxMarkerPerimeterRate = 4.0;
  erc_vision_node_B.b_m.polygonalApproxAccuracyRate = 0.03;
  erc_vision_node_B.b_m.minCornerDistanceRate = 0.05;
  erc_vision_node_B.b_m.minDistanceToBorder = 3;
  erc_vision_node_B.b_m.minMarkerDistanceRate = 0.05;
  erc_vision_node_B.b_m.perspectiveRemovePixelPerCell = 4;
  erc_vision_node_B.b_m.perspectiveRemoveIgnoredMarginPerCell = 0.13;
  erc_vision_node_B.b_m.markerBorderBits = 1;
  erc_vision_node_B.b_m.minOtsuStdDev = 5.0;
  erc_vision_node_B.b_m.maxErroneousBitsInBorderRate = 0.35;
  erc_vision_node_B.b_m.errorCorrectionRate = 0.6;
  erc_vision_node_B.b_m.detectInvertedMarker = false;
  erc_vision_node_B.b_m.useAruco3Detection = false;
  erc_vision_node_B.b_m.minSideLengthCanonicalImg = 32;
  erc_vision_node_B.b_m.minMarkerLengthRatioOriginalImg = 0.0F;
  erc_vision_node_B.b_m.cornerRefinementMethod = 0.0;
  erc_vision_node_B.b_m.cornerRefinementWinSize = 5;
  erc_vision_node_B.b_m.cornerRefinementMaxIterations = 30;
  erc_vision_node_B.b_m.cornerRefinementMinAccuracy = 0.1;
  detectionsObj = NULL;
  erc_vision_node_B.n = 0;
  erc_vision_node_B.rejectionLength = 0;
  erc_vision_node_B.poseLength = 0;
  erc_vision_node_B.numDetections = readArucoImplCore(&erc_vision_node_B.c_I[0],
    true, 480, 640, &erc_vision_node_B.markersProc[0], 1,
    &erc_vision_node_B.markersLength[0], erc_vision_node_B.b_m, true, 0.15,
    &erc_vision_node_B.camMatrix[0], &erc_vision_node_B.distCoeffs[0],
    &detectionsObj, &erc_vision_node_B.n, &erc_vision_node_B.rejectionLength,
    &erc_vision_node_B.poseLength);
  erc_vision_node_B.locs.set_size(4, 2, static_cast<int32_T>
    (erc_vision_node_B.numDetections));
  erc_vision_node_B.rejectionsCell.set_size(4, 2,
    erc_vision_node_B.rejectionLength);
  varargout_1.set_size(1, static_cast<int32_T>(erc_vision_node_B.numDetections));
  erc_vision_node_B.famLength.set_size(1, static_cast<int32_T>
    (erc_vision_node_B.numDetections));
  erc_vision_node_B.familyNames.set_size(1, erc_vision_node_B.n);
  for (erc_vision_node_B.rejectionLength = 0; erc_vision_node_B.rejectionLength <
       erc_vision_node_B.n; erc_vision_node_B.rejectionLength++) {
    erc_vision_node_B.familyNames[erc_vision_node_B.rejectionLength] = ' ';
  }

  erc_vision_node_B.rotMatrices.set_size(3, 3, erc_vision_node_B.poseLength);
  erc_vision_node_B.transVectors.set_size(3, erc_vision_node_B.poseLength);
  erc_vision_node_B.rejectionLength = 0;
  assignOutputs(&varargout_1[erc_vision_node_B.rejectionLength],
                &erc_vision_node_B.locs[0],
                &erc_vision_node_B.famLength[erc_vision_node_B.rejectionLength],
                &erc_vision_node_B.familyNames[erc_vision_node_B.rejectionLength],
                &erc_vision_node_B.rejectionsCell[0],
                &erc_vision_node_B.rotMatrices[0],
                &erc_vision_node_B.transVectors[0], detectionsObj, true);
  deleteResultPtr(detectionsObj);
  varargout_2.set_size(4, 2, erc_vision_node_B.locs.size(2));
  erc_vision_node_B.loop_ub = erc_vision_node_B.locs.size(2) << 3;
  for (erc_vision_node_B.rejectionLength = 0; erc_vision_node_B.rejectionLength <
       erc_vision_node_B.loop_ub; erc_vision_node_B.rejectionLength++) {
    varargout_2[erc_vision_node_B.rejectionLength] =
      erc_vision_node_B.locs[erc_vision_node_B.rejectionLength];
  }

  erc_vision_node_B.poseLength = erc_vision_node_B.transVectors.size(1);
  for (erc_vision_node_B.rejectionLength = 0; erc_vision_node_B.rejectionLength <
       3; erc_vision_node_B.rejectionLength++) {
    erc_vision_node_B.camMatrix[3 * erc_vision_node_B.rejectionLength] =
      erc_vision_node_B.rotMatrices[erc_vision_node_B.rotMatrices.size(0) *
      erc_vision_node_B.rejectionLength];
    erc_vision_node_B.camMatrix[3 * erc_vision_node_B.rejectionLength + 1] =
      erc_vision_node_B.rotMatrices[erc_vision_node_B.rotMatrices.size(0) *
      erc_vision_node_B.rejectionLength + 1];
    erc_vision_node_B.camMatrix[3 * erc_vision_node_B.rejectionLength + 2] =
      erc_vision_node_B.rotMatrices[erc_vision_node_B.rotMatrices.size(0) *
      erc_vision_node_B.rejectionLength + 2];
    erc_vision_node_B.transVectors_data[erc_vision_node_B.rejectionLength] =
      erc_vision_node_B.transVectors[erc_vision_node_B.rejectionLength];
  }

  erc_v_rigidtform3d_rigidtform3d(erc_vision_node_B.camMatrix,
    erc_vision_node_B.transVectors_data, erc_vision_node_B.expl_temp_data_b,
    erc_vision_node_B.markersLength, erc_vision_node_B.expl_temp_data,
    erc_vision_node_B.expl_temp_size, varargout_3_Data);
  if (erc_vision_node_B.transVectors.size(1) >= 2) {
    for (erc_vision_node_B.n = 2; erc_vision_node_B.n <=
         erc_vision_node_B.poseLength; erc_vision_node_B.n++) {
      for (erc_vision_node_B.rejectionLength = 0;
           erc_vision_node_B.rejectionLength < 3;
           erc_vision_node_B.rejectionLength++) {
        erc_vision_node_B.camMatrix[3 * erc_vision_node_B.rejectionLength] =
          erc_vision_node_B.rotMatrices[erc_vision_node_B.rotMatrices.size(0) *
          erc_vision_node_B.rotMatrices.size(1) * (erc_vision_node_B.n - 1) +
          erc_vision_node_B.rotMatrices.size(0) *
          erc_vision_node_B.rejectionLength];
        erc_vision_node_B.camMatrix[3 * erc_vision_node_B.rejectionLength + 1] =
          erc_vision_node_B.rotMatrices[(erc_vision_node_B.rotMatrices.size(0) *
          erc_vision_node_B.rotMatrices.size(1) * (erc_vision_node_B.n - 1) +
          erc_vision_node_B.rotMatrices.size(0) *
          erc_vision_node_B.rejectionLength) + 1];
        erc_vision_node_B.camMatrix[3 * erc_vision_node_B.rejectionLength + 2] =
          erc_vision_node_B.rotMatrices[(erc_vision_node_B.rotMatrices.size(0) *
          erc_vision_node_B.rotMatrices.size(1) * (erc_vision_node_B.n - 1) +
          erc_vision_node_B.rotMatrices.size(0) *
          erc_vision_node_B.rejectionLength) + 2];
        erc_vision_node_B.transVectors_data[erc_vision_node_B.rejectionLength] =
          erc_vision_node_B.transVectors[(erc_vision_node_B.n - 1) *
          erc_vision_node_B.transVectors.size(0) +
          erc_vision_node_B.rejectionLength];
      }

      erc_v_rigidtform3d_rigidtform3d(erc_vision_node_B.camMatrix,
        erc_vision_node_B.transVectors_data, erc_vision_node_B.expl_temp_data_b,
        erc_vision_node_B.markersLength, erc_vision_node_B.expl_temp_data,
        erc_vision_node_B.expl_temp_size, erc_vision_node_B.rhs_Data);
      if (erc_vision_node_B.n > varargout_3_Data.size(1)) {
        erc_vision_node_B.dataArray.set_size(1, erc_vision_node_B.n);
        erc_vision_node_B.loop_ub = varargout_3_Data.size(1);
        for (erc_vision_node_B.rejectionLength = 0;
             erc_vision_node_B.rejectionLength < erc_vision_node_B.loop_ub;
             erc_vision_node_B.rejectionLength++) {
          erc_vision_node_B.dataArray[erc_vision_node_B.rejectionLength] =
            varargout_3_Data[erc_vision_node_B.rejectionLength];
        }

        erc_vision_node_B.dataArray[erc_vision_node_B.n - 1] =
          erc_vision_node_B.rhs_Data[0];
        erc_vision_node_B.loop_ub = erc_vision_node_B.dataArray.size(1);
        varargout_3_Data.set_size(1, erc_vision_node_B.dataArray.size(1));
        for (erc_vision_node_B.rejectionLength = 0;
             erc_vision_node_B.rejectionLength < erc_vision_node_B.loop_ub;
             erc_vision_node_B.rejectionLength++) {
          varargout_3_Data[erc_vision_node_B.rejectionLength] =
            erc_vision_node_B.dataArray[erc_vision_node_B.rejectionLength];
        }
      } else {
        varargout_3_Data[erc_vision_node_B.n - 1] = erc_vision_node_B.rhs_Data[0];
      }
    }
  }
}

// Function for MATLAB Function: '<Root>/MATLAB Function'
void erc_vision_node::OneDimArrayBehaviorTransform_pa(const
  rigidtform3d_erc_vision_node_T *b_this, real_T idx, real_T this1_Translation[3])
{
  int8_T tmp[2];
  static const int8_T b[4] = { 0, 0, 0, 1 };

  int32_T dataArray_data_tmp;
  erc_vision_node_B.dataArray_data = b_this->Data[static_cast<int32_T>(idx) - 1];
  for (int32_T i = 0; i < 3; i++) {
    dataArray_data_tmp = 3 * i;
    erc_vision_node_B.dataArray_data_k[dataArray_data_tmp] =
      erc_vision_node_B.dataArray_data.R.data[dataArray_data_tmp];
    dataArray_data_tmp = 3 * i + 1;
    erc_vision_node_B.dataArray_data_k[dataArray_data_tmp] =
      erc_vision_node_B.dataArray_data.R.data[dataArray_data_tmp];
    dataArray_data_tmp = 3 * i + 2;
    erc_vision_node_B.dataArray_data_k[dataArray_data_tmp] =
      erc_vision_node_B.dataArray_data.R.data[dataArray_data_tmp];
    erc_vision_node_B.dataArray_data_k[i + 9] =
      erc_vision_node_B.dataArray_data.Translation.data[i];
  }

  tmp[0] = 3;
  for (int32_T i = 0; i < 4; i++) {
    for (dataArray_data_tmp = 0; dataArray_data_tmp < 3; dataArray_data_tmp++) {
      erc_vision_node_B.dataArray_data_c[dataArray_data_tmp + (i << 2)] =
        erc_vision_node_B.dataArray_data_k[tmp[0] * i + dataArray_data_tmp];
    }

    erc_vision_node_B.dataArray_data_c[(i << 2) + 3] = b[i];
  }

  this1_Translation[0] = erc_vision_node_B.dataArray_data_c[12];
  this1_Translation[1] = erc_vision_node_B.dataArray_data_c[13];
  this1_Translation[2] = erc_vision_node_B.dataArray_data_c[14];
}

void erc_vision_node::Raspiv4l2Capture_Raspiv4l2Captu
  (codertarget_raspi_internal_Ra_T *obj)
{
  // Start for MATLABSystem: '<Root>/V4L2 Video Capture'
  obj->ManualFocus = 0.5;
  obj->BrightnessInternal = 0.5;
  obj->SaturationInternal = 0.5;
  obj->ContrastInternal = 0.5;
  obj->SharpnessInternal = 0.5;
  obj->CameraZoomInternal = 0.5;
  obj->ManualFocusInternal = 0.5;
  obj->CameraPanInternal = 0.0;
  obj->CameraTiltInternal = 0.0;
  obj->EnableManualFocusInternal = false;
  obj->isInitialized = 0;
  obj->matlabCodegenIsDeleted = false;
}

void erc_vision_node::erc_vision_nod_SystemCore_setup
  (codertarget_raspi_internal_Ra_T *obj)
{
  int32_T camIndex;
  char_T devName[13];
  static const char_T devName_0[13] = "/dev/video10";
  static const char_T b_errorMessage[101] =
    "Webcam cannot be initialized properly. Please check if the device supports the specified resolution.";

  // Start for MATLABSystem: '<Root>/V4L2 Video Capture'
  obj->isInitialized = 1;
  getCameraList();
  for (camIndex = 0; camIndex < 13; camIndex++) {
    devName[camIndex] = devName_0[camIndex];
  }

  // Start for MATLABSystem: '<Root>/V4L2 Video Capture'
  camIndex = getCameraAddrIndex(&devName[0], 12U);
  camIndex = validateResolution(camIndex, 640, 480);
  if (camIndex >= 0) {
    EXT_webcamInit(0, 10, 0, 0, 0, 0, 640U, 480U, 2U, 2U, 1U,
                   0.06666666666666667);
  } else {
    memcpy(&erc_vision_node_B.b_errorMessage[0], &b_errorMessage[0], 101U *
           sizeof(char_T));
    std::perror(&erc_vision_node_B.b_errorMessage[0]);
    std::exit(0);
  }

  v4l2Capture_updateV4L2Settings(obj, true);
  obj->isSetupComplete = true;
}

void erc_vision_node::erc_vision__Publisher_setupImpl(const
  ros_slros2_internal_block_Pub_T *obj)
{
  rmw_qos_profile_t qos_profile;
  sJ4ih70VmKcvCeguWN0mNVF deadline;
  sJ4ih70VmKcvCeguWN0mNVF lifespan;
  sJ4ih70VmKcvCeguWN0mNVF liveliness_lease_duration;
  static const char_T b_zeroDelimTopic[20] = "/erc/vision_targets";
  qos_profile = rmw_qos_profile_default;

  // Start for MATLABSystem: '<S3>/SinkBlock'
  deadline.sec = 0.0;
  deadline.nsec = 0.0;
  lifespan.sec = 0.0;
  lifespan.nsec = 0.0;
  liveliness_lease_duration.sec = 0.0;
  liveliness_lease_duration.nsec = 0.0;
  SET_QOS_VALUES(qos_profile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, static_cast<
                 size_t>(10.0), RMW_QOS_POLICY_DURABILITY_VOLATILE,
                 RMW_QOS_POLICY_RELIABILITY_RELIABLE, deadline, lifespan,
                 RMW_QOS_POLICY_LIVELINESS_AUTOMATIC, liveliness_lease_duration,
                 (bool)obj->QOSAvoidROSNamespaceConventions);
  for (int32_T i = 0; i < 20; i++) {
    // Start for MATLABSystem: '<S3>/SinkBlock'
    erc_vision_node_B.b_zeroDelimTopic[i] = b_zeroDelimTopic[i];
  }

  Pub_erc_vision_node_3.createPublisher(&erc_vision_node_B.b_zeroDelimTopic[0],
    qos_profile);
}

// Model step function
void erc_vision_node::step()
{
  boolean_T exitg1;

  // MATLABSystem: '<Root>/V4L2 Video Capture'
  if (erc_vision_node_DW.obj.Brightness != 0.5) {
    erc_vision_node_DW.obj.Brightness = 0.5;
  }

  if (erc_vision_node_DW.obj.Saturation != 0.5) {
    erc_vision_node_DW.obj.Saturation = 0.5;
  }

  if (erc_vision_node_DW.obj.Contrast != 0.5) {
    erc_vision_node_DW.obj.Contrast = 0.5;
  }

  if (erc_vision_node_DW.obj.Sharpness != 0.5) {
    erc_vision_node_DW.obj.Sharpness = 0.5;
  }

  if (erc_vision_node_DW.obj.CameraPan != 0.0) {
    erc_vision_node_DW.obj.CameraPan = 0.0;
  }

  if (erc_vision_node_DW.obj.CameraTilt != 0.0) {
    erc_vision_node_DW.obj.CameraTilt = 0.0;
  }

  if (erc_vision_node_DW.obj.CameraZoom != 0.5) {
    erc_vision_node_DW.obj.CameraZoom = 0.5;
  }

  erc_vision_node_SystemCore_step(&erc_vision_node_DW.obj,
    erc_vision_node_B.varargin_2, erc_vision_node_B.varargin_3,
    erc_vision_node_B.uv);

  // MATLAB Function: '<Root>/MATLAB Function' incorporates:
  //   MATLABSystem: '<Root>/V4L2 Video Capture'

  for (erc_vision_node_B.targetIdx = 0; erc_vision_node_B.targetIdx < 640;
       erc_vision_node_B.targetIdx++) {
    for (erc_vision_node_B.i_h = 0; erc_vision_node_B.i_h < 480;
         erc_vision_node_B.i_h++) {
      erc_vision_node_B.varargin_1[erc_vision_node_B.i_h + 480 *
        erc_vision_node_B.targetIdx] = erc_vision_node_B.varargin_2[640 *
        erc_vision_node_B.i_h + erc_vision_node_B.targetIdx];
    }
  }

  for (erc_vision_node_B.targetIdx = 0; erc_vision_node_B.targetIdx < 640;
       erc_vision_node_B.targetIdx++) {
    for (erc_vision_node_B.i_h = 0; erc_vision_node_B.i_h < 480;
         erc_vision_node_B.i_h++) {
      erc_vision_node_B.varargin_2[erc_vision_node_B.i_h + 480 *
        erc_vision_node_B.targetIdx] = erc_vision_node_B.varargin_3[640 *
        erc_vision_node_B.i_h + erc_vision_node_B.targetIdx];
    }
  }

  for (erc_vision_node_B.targetIdx = 0; erc_vision_node_B.targetIdx < 640;
       erc_vision_node_B.targetIdx++) {
    for (erc_vision_node_B.i_h = 0; erc_vision_node_B.i_h < 480;
         erc_vision_node_B.i_h++) {
      erc_vision_node_B.varargin_3[erc_vision_node_B.i_h + 480 *
        erc_vision_node_B.targetIdx] = erc_vision_node_B.uv[640 *
        erc_vision_node_B.i_h + erc_vision_node_B.targetIdx];
    }
  }

  memcpy(&erc_vision_node_B.frame[0], &erc_vision_node_B.varargin_1[0], 307200U *
         sizeof(uint8_T));
  memcpy(&erc_vision_node_B.frame[307200], &erc_vision_node_B.varargin_2[0],
         307200U * sizeof(uint8_T));
  memcpy(&erc_vision_node_B.frame[614400], &erc_vision_node_B.varargin_3[0],
         307200U * sizeof(uint8_T));
  cameraIntrinsics_cameraIntrinsi(&erc_vision_node_B.intrinsics);

  // BusAssignment: '<Root>/Bus Assignment' incorporates:
  //   MATLAB Function: '<Root>/MATLAB Function'

  erc_vision_node_B.BusAssignment.x = 0.0;
  erc_vision_node_B.BusAssignment.y = 0.0;
  erc_vision_node_B.BusAssignment.z = 0.0;

  // MATLAB Function: '<Root>/MATLAB Function'
  erc_vision_node_readArucoMarker(erc_vision_node_B.frame,
    &erc_vision_node_B.intrinsics, erc_vision_node_B.ids, erc_vision_node_B.a__1,
    erc_vision_node_B.poses.Data);
  if (erc_vision_node_B.ids.size(1) != 0) {
    erc_vision_node_B.targetIdx = 0;
    erc_vision_node_B.i_h = 0;
    exitg1 = false;
    while (!exitg1 && (erc_vision_node_B.i_h <= erc_vision_node_B.ids.size(1) -
                       1)) {
      if (erc_vision_node_B.ids[erc_vision_node_B.i_h] == 102.0) {
        erc_vision_node_B.targetIdx = erc_vision_node_B.i_h + 1;
        exitg1 = true;
      } else {
        erc_vision_node_B.i_h++;
      }
    }

    if (erc_vision_node_B.targetIdx == 0) {
      erc_vision_node_B.i_h = 0;
      exitg1 = false;
      while (!exitg1 && (erc_vision_node_B.i_h <= erc_vision_node_B.ids.size(1)
                         - 1)) {
        if (erc_vision_node_B.ids[erc_vision_node_B.i_h] == 101.0) {
          erc_vision_node_B.targetIdx = erc_vision_node_B.i_h + 1;
          exitg1 = true;
        } else {
          erc_vision_node_B.i_h++;
        }
      }
    }

    if (erc_vision_node_B.targetIdx != 0) {
      OneDimArrayBehaviorTransform_pa(&erc_vision_node_B.poses,
        static_cast<real_T>(erc_vision_node_B.targetIdx),
        erc_vision_node_B.b_Translation);

      // BusAssignment: '<Root>/Bus Assignment'
      erc_vision_node_B.BusAssignment.x = erc_vision_node_B.b_Translation[0];
      erc_vision_node_B.BusAssignment.y = erc_vision_node_B.b_Translation[1];
      erc_vision_node_B.BusAssignment.z =
        erc_vision_node_B.ids[erc_vision_node_B.targetIdx - 1];
    }
  }

  // MATLABSystem: '<S3>/SinkBlock'
  Pub_erc_vision_node_3.publish(&erc_vision_node_B.BusAssignment);
}

// Model initialize function
void erc_vision_node::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // Start for MATLABSystem: '<Root>/V4L2 Video Capture'
  erc_vision_node_DW.obj.matlabCodegenIsDeleted = true;
  Raspiv4l2Capture_Raspiv4l2Captu(&erc_vision_node_DW.obj);
  erc_vision_node_DW.obj.Brightness = 0.5;
  erc_vision_node_DW.obj.Saturation = 0.5;
  erc_vision_node_DW.obj.Contrast = 0.5;
  erc_vision_node_DW.obj.Sharpness = 0.5;
  erc_vision_node_DW.obj.CameraPan = 0.0;
  erc_vision_node_DW.obj.CameraTilt = 0.0;
  erc_vision_node_DW.obj.CameraZoom = 0.5;
  erc_vision_nod_SystemCore_setup(&erc_vision_node_DW.obj);

  // Start for MATLABSystem: '<S3>/SinkBlock'
  erc_vision_node_DW.obj_h.QOSAvoidROSNamespaceConventions = false;
  erc_vision_node_DW.obj_h.matlabCodegenIsDeleted = false;
  erc_vision_node_DW.obj_h.isSetupComplete = false;
  erc_vision_node_DW.obj_h.isInitialized = 1;
  erc_vision__Publisher_setupImpl(&erc_vision_node_DW.obj_h);
  erc_vision_node_DW.obj_h.isSetupComplete = true;
}

// Model terminate function
void erc_vision_node::terminate()
{
  // Terminate for MATLABSystem: '<Root>/V4L2 Video Capture'
  if (!erc_vision_node_DW.obj.matlabCodegenIsDeleted) {
    erc_vision_node_DW.obj.matlabCodegenIsDeleted = true;
    if ((erc_vision_node_DW.obj.isInitialized == 1) &&
        erc_vision_node_DW.obj.isSetupComplete) {
      EXT_webcamTerminate(0, 10);
    }
  }

  // End of Terminate for MATLABSystem: '<Root>/V4L2 Video Capture'

  // Terminate for MATLABSystem: '<S3>/SinkBlock'
  if (!erc_vision_node_DW.obj_h.matlabCodegenIsDeleted) {
    erc_vision_node_DW.obj_h.matlabCodegenIsDeleted = true;
    if ((erc_vision_node_DW.obj_h.isInitialized == 1) &&
        erc_vision_node_DW.obj_h.isSetupComplete) {
      Pub_erc_vision_node_3.resetPublisherPtr();//();
    }
  }

  // End of Terminate for MATLABSystem: '<S3>/SinkBlock'
}

// Constructor
erc_vision_node::erc_vision_node() :
  erc_vision_node_B(),
  erc_vision_node_DW(),
  erc_vision_node_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
erc_vision_node::~erc_vision_node()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_erc_vision_node_T * erc_vision_node::getRTM()
{
  return (&erc_vision_node_M);
}

const char_T* RT_MODEL_erc_vision_node_T::getErrorStatus() const
{
  return (errorStatus);
}

void RT_MODEL_erc_vision_node_T::setErrorStatus(const char_T* const volatile
  aErrorStatus)
{
  (errorStatus = aErrorStatus);
}

//
// File trailer for generated code.
//
// [EOF]
//
