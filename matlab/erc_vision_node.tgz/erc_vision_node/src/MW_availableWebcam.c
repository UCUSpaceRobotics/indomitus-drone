/* Copyright 2020-2026 The MathWorks, Inc. */

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||            \
     defined(RSIM_WITH_SL_SOLVER))

#include "MW_availableWebcam.h"

#else

#include "MW_availableWebcam.h"
#include <ctype.h>
#include <linux/videodev2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/fcntl.h> //needed for file closing
#include <sys/ioctl.h>
#include <unistd.h>

#define MW_MAXV4L2DEVICES 10
#define MW_WEBCAMNAMELEN 1024

struct webCam {
    char Name[MW_WEBCAMNAMELEN];
    char Address[MW_WEBCAMNAMELEN];
};

static struct webCam wc[MW_MAXV4L2DEVICES];
static int numberOfConnections = 0;


static void MW_trim(char* const str) {
    int index, i;
    /* Trim leading white spaces  */
    index = 0;
    while (str[index] == ' ' || str[index] == '\t' || str[index] == '\n') {
        index++;
    }
    /* Shift all trailing characters to its left */
    i = 0;
    while (str[i + index] != '\0') {
        str[i] = str[i + index];
        i++;
    }
    str[i] = '\0'; // Terminate string with NULL

    /* Trim trailing white spaces  */
    i = 0;
    index = -1;
    while (str[i] != '\0') {
        if (str[i] != ' ' && str[i] != '\t' && str[i] != '\n') {
            index = i;
        }

        i++;
    }
    /* Mark the next character to last non white space character as NULL */
    str[index + 1] = '\0';
}

static int validateResolutionLimits(int imWidth, int imHeight, int minWidth,
                                    int minHeight, int maxWidth,
                                    int maxHeight) {
    // Check if the image width is within the limits
    if ((imWidth < minWidth) || (imWidth > maxWidth)) {
        return 0; // Width is outside the limits
    }

    // Check if the image height is within the limits
    if ((imHeight < minHeight) || (imHeight > maxHeight)) {
        return 0; // Height is outside the limits
    }

    return 1; // Both width and height are within the limits
}

int validateResolution(int camIndex, int imWidth,
                                         int imHeight) {
    struct v4l2_frmsizeenum frameSize;
    int fd;
    // status >=0 is a valid resolution
    int status = -1;
    if (camIndex < 0 || camIndex >= numberOfConnections) {
        return status;
    }
    // We handle only YUYV pixel formats
    frameSize.pixel_format = V4L2_PIX_FMT_YUYV;

    fd = open(wc[camIndex].Address, O_RDWR);
    if (fd < 0) {
        MW_REPORT_ERROR_ARGS1("Unable to open Camera :\n%s\n",
                              wc[camIndex].Name);
    }

    for (frameSize.index = 0;
         ioctl(fd, VIDIOC_ENUM_FRAMESIZES, &frameSize) == 0;
         frameSize.index++) {
        switch (frameSize.type) {
        case V4L2_FRMSIZE_TYPE_DISCRETE:
            // Check if user requested resolution can be matched by the device
            if ((imWidth == frameSize.discrete.width) &&
                (imHeight == frameSize.discrete.height)) {
                status = 1;
                goto end_validation;
            }
            break;
        case V4L2_FRMSIZE_TYPE_STEPWISE:
            if (validateResolutionLimits(
                    imWidth, imHeight, frameSize.stepwise.min_width,
                    frameSize.stepwise.min_height, frameSize.stepwise.max_width,
                    frameSize.stepwise.max_height) == 1) {
                // Check if user requested image resolution increments correctly
                // according to step size
                if (((imWidth - frameSize.stepwise.min_width) %
                         frameSize.stepwise.step_width ==
                     0) &&
                    ((imHeight - frameSize.stepwise.min_height) %
                         frameSize.stepwise.step_height ==
                     0)) {
                    status = 1;
                    goto end_validation;
                }
            }
            break;
        case V4L2_FRMSIZE_TYPE_CONTINUOUS:
            if (validateResolutionLimits(
                    imWidth, imHeight, frameSize.stepwise.min_width,
                    frameSize.stepwise.min_height, frameSize.stepwise.max_width,
                    frameSize.stepwise.max_height) == 1) {
                status = 1;
                goto end_validation;
            }
            break;
        default:
            break;
        }
    }
end_validation:
    close(fd);
    return status;
}

void getCameraList() {
/*Get the list of web cameras*/
    FILE *fp;
    char webCamName[MW_WEBCAMNAMELEN];
    char* const bcmCodec = "bcm2835-codec";
    char* const bcmIsp = "bcm2835-isp";
    char* const devName = "/dev/video";
    int i = 0;
    /* On few hardware with Bullseye OS, skip following lines from V4l2 command output
     */
    char* const mediaName = "/dev/media";
    char* const rpivid = "rpivid";
    /* Additional platform devices to skip on Bookworm and Pi 5 */
    char* const unicam = "unicam";
    char* const pispbe = "pispbe";
    char* const rp1cfe = "rp1-cfe";
    char* const mmalSvc = "mmal service";
    char* const rpiHevc = "rpi-hevc-dec";
    char* const bcmV4l2 = "bcm2835-v4l2";

    /* Reset state from any prior call */
    numberOfConnections = 0;
    memset(wc, 0, sizeof(wc));

    memset(webCamName, 0, MW_WEBCAMNAMELEN * sizeof(webCamName[0]));
    /* Open the command for reading. */
    /*
    Expected output for /usr/bin/v4l2-ctl --list-devices :

    bcm2835-codec (platform:bcm2835-codec):
        /dev/video10
        /dev/video11
        /dev/video12
        /dev/media10

    mmal service 16.1 (platform:bcm2835-v4l2):
        /dev/video0

    rpivid (platform:rpivid): (On few Raspberry Pis with Bullseye)
        /dev/video19
        /dev/media0


    Microsoft® LifeCam Cinema(TM): (usb-3f980000.usb-1.1.3):
        /dev/video1
        /dev/video2
        /dev/media3

    */
    fp = popen("/usr/bin/v4l2-ctl --list-devices", "r");
    if (fp == NULL) {
        MW_REPORT_ERROR("Failed to read camera list\n");
        // main_terminate();
    }

    /* Read the output a line at a time - output it. */

    while (fgets(webCamName, sizeof(webCamName) - 1, fp) != NULL) {
        MW_trim(webCamName);
        /* Skip the unnecessary content while reading the v4l2 output */
        if ((strstr(webCamName, bcmCodec) != NULL) ||
            (strstr(webCamName, bcmIsp) != NULL) ||
            (strstr(webCamName, mediaName) != NULL) ||
            (strstr(webCamName, rpivid) != NULL) ||
            (strstr(webCamName, unicam) != NULL) ||
            (strstr(webCamName, pispbe) != NULL) ||
            (strstr(webCamName, rp1cfe) != NULL) ||
            (strstr(webCamName, mmalSvc) != NULL) ||
            (strstr(webCamName, rpiHevc) != NULL) ||
            (strstr(webCamName, bcmV4l2) != NULL)) {
            /*Skip adding bcmCodec to webcamList */
            memset(webCamName, 0, MW_WEBCAMNAMELEN * sizeof(webCamName[0]));
            continue;
        }
        if (strstr(webCamName, devName) != NULL) {
            /*Skip adding /dev/video with YUV format to available webcam  */
            memset(webCamName, 0, MW_WEBCAMNAMELEN * sizeof(webCamName[0]));
            continue;
        }
        if (strlen(webCamName) == 0) {
            /*Skip the empty line */
            memset(webCamName, 0, MW_WEBCAMNAMELEN * sizeof(webCamName[0]));
            continue;
        }
        if (i >= MW_MAXV4L2DEVICES) {
            MW_REPORT_ERROR("Too many video devices detected, some will be ignored.\n");
            break;
        }
        strcpy(wc[i].Name, webCamName);
        const size_t len = strlen(wc[i].Name); // Get the length of the string
        if (len > 0 && wc[i].Name[len - 1] == ':') { // Check if the last character is a colon
            wc[i].Name[len - 1] = '\0'; // Replace it with the null terminator
        }
        // Get the video device file name information
        memset(webCamName, 0, MW_WEBCAMNAMELEN * sizeof(webCamName[0]));
        if (fgets(webCamName, sizeof(webCamName) - 1, fp) == NULL) {
            break;
        }
        MW_trim(webCamName);
        strcpy(wc[i].Address, webCamName);
        // register the count of available webcam
        numberOfConnections++;
        i++;
        memset(webCamName, 0, MW_WEBCAMNAMELEN * sizeof(webCamName[0]));
    }
    pclose(fp);
}

int getCameraAddrIndex(char* const cameraName, unsigned int cameraNameLen) {

    #define MAX_CAM_NAME_LEN 150
    /* For the given camera name, find its index in the webCam
     * structure*/
    int i, j;
    char cameraNameCopied[MAX_CAM_NAME_LEN] = "";

    MW_trim(cameraName);
    if (cameraNameLen >= MAX_CAM_NAME_LEN) {
        cameraNameLen = MAX_CAM_NAME_LEN - 1;
    }
    memcpy(cameraNameCopied, cameraName, cameraNameLen * sizeof(cameraName[0]));
    cameraNameCopied[cameraNameLen] = '\0';

    for (i = 0; i < (numberOfConnections); i++) {

        if ((strcmp(cameraNameCopied, wc[i].Name) == 0) ||
            (strcmp(cameraNameCopied, wc[i].Address) == 0)) {
            return (i);
        }
    }
    MW_REPORT_ERROR(
        "Selected Web Camera did not match any available Web Cameras "
        "on your Raspberry Pi.\n");
    MW_REPORT_ERROR_ARGS1("Selected Web Camera :\n%s\n", cameraName);
    MW_REPORT_ERROR("Available Web Cameras:\n");
    MW_REPORT_ERROR("Index\t||\tName\t||\tAddress\t\n");
    for (j = 0; j < (numberOfConnections); j++) {
        MW_REPORT_ERROR_ARGS3("%d\t||%s||%s\n", j, wc[j].Name, wc[j].Address);
    }
    return (-1);
}

int getCameraDeviceNumFromIndex(unsigned int index)
{
    // This function returns the respective device number from the device index
    /* Eg: The device index for Microsoft camera from the following command is 2 since its second in the list
    But the device number of this camera is 0 corresponds to '/dev/video0'
    $ v4l2-ctl --list-devices
            unicam (platform:3f801000.csi):
                    /dev/video2
                    /dev/video3
                    /dev/media2

            Microsoft® LifeCam Cinema(TM): (usb-3f980000.usb-1.3):
                    /dev/video0
                    /dev/video1
                    /dev/media4

    */
    if (index >= numberOfConnections) {
        MW_REPORT_ERROR_ARGS1("Device index %d is out of range.\n", index);
        return -1;
    }

    int devNum = -1;
    if (sscanf(wc[index].Address, "/dev/video%d", &devNum) != 1) {
        MW_REPORT_ERROR_ARGS1("Unable to parse device number from: %s\n",
                              wc[index].Address);
        return -1;
    }
    return devNum;
}

#endif
/* LocalWords:  usr ctl webcam availablewebcam framesize YUYV
 */
